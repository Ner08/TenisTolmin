<div class="bg-zinc-900 shadow-inner">
    <div
        class="pb-4 pt-5 md:pt-3 text-gray-100 text-2xl font-bold items-center justify-between max-w-screen-2xl flex flex-wrap mx-auto p-3">
        <h1 class="mr-4">{{ $title }}</h1>
    </div>
</div>
