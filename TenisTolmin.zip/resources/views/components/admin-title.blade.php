<div class="bg-zinc-900 shadow-inner">
    <div
        class="pb-4 pt-5 md:pt-3 text-gray-100 text-2xl font-bold items-center justify-between max-w-screen-2xl flex flex-wrap mx-auto p-3">
        <h1 class="underline mr-4">{{ $title }}</h1>
       {{--  <div class="flex items-center">
            <a href="#lige" class="text-lg text-gray-100 hover:text-gray-300 mr-4">Lige in turnirji</a>
            <a href="#igralci" class="text-lg text-gray-100 hover:text-gray-300 mr-4">Igralci</a>
            <a href="#novice" class="text-lg text-gray-100 hover:text-gray-300 mr-4">Novice</a>
            <a href="#dogodki" class="text-lg text-gray-100 hover:text-gray-300 mr-4">Dogodki</a>
            <a href="#galerija" class="text-lg text-gray-100 hover:text-gray-300">Galerija</a>
        </div> --}}
    </div>
</div>
