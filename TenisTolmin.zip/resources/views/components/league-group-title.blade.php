<div class="flex mx-2- p-2 pl-10 bg-zinc-900 justify-between">
    <h1 class="p-2 inline-block text-white font-bold text-2xl">{{ $title }}</h1>
</div>
