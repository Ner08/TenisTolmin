<div class="container px-4 mx-auto py-8">
    <h1 class="text-3xl font-bold mb-3">Galerija</h1>
    <h4 class="text-lg text-gray-600 mb-8">Naša teniška galerija ponuja vpogled v dogodke našega teniškega kluba. Slike zajemajo igralne trenutke in sproščena druženja, ki odražajo strast in povezanost naših članov,</h4>
    
    <?php if($gallery->isEmpty()): ?>
        <?php if (isset($component)) { $__componentOriginal4f22a152e0729cd34293e65bd200d933 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4f22a152e0729cd34293e65bd200d933 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.empty','data' => ['model1' => 'Galerija']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('empty'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['model1' => 'Galerija']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4f22a152e0729cd34293e65bd200d933)): ?>
<?php $attributes = $__attributesOriginal4f22a152e0729cd34293e65bd200d933; ?>
<?php unset($__attributesOriginal4f22a152e0729cd34293e65bd200d933); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4f22a152e0729cd34293e65bd200d933)): ?>
<?php $component = $__componentOriginal4f22a152e0729cd34293e65bd200d933; ?>
<?php unset($__componentOriginal4f22a152e0729cd34293e65bd200d933); ?>
<?php endif; ?>
    <?php endif; ?>
    <div class="grid grid-cols-3 gap-1">
        <?php $__currentLoopData = $gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="p-2 bg-gray-100 rounded-lg text-gray-900 shadow-md">
                <img src="<?php echo e(asset('storage/' . $item->g_image)); ?>" alt="<?php echo e($item->g_title); ?>" class="w-full h-auto rounded-md shadow cursor-pointer" onclick="showFullImage('<?php echo e(asset('storage/' . $item->g_image)); ?>')">
                <p class="text-center pt-1 font-semibold text-gray-800"><?php echo e($item->g_title); ?></p>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="flex justify-center mt-8">
        <a href="<?php echo e(route('gallery')); ?>"
            class="bg-gray-900 hover:bg-gray-800 text-white text-lg font-bold py-2 px-6 rounded-lg transition duration-300 ease-in-out transform hover:-translate-y-1">
            Več slik
        </a>
    </div>
</div>

<!-- JavaScript function to show full image -->
<script>
    function showFullImage(imageUrl) {
        // Create a modal overlay
        const overlay = document.createElement('div');
        overlay.classList.add('fixed', 'top-0', 'left-0', 'w-screen', 'h-screen', 'bg-black', 'bg-opacity-75', 'flex',
            'justify-center', 'items-center', 'z-50');

        // Create a container for the image and close button
        const container = document.createElement('div');
        container.classList.add('relative');

        // Create a close button
        const closeButton = document.createElement('button');
        closeButton.innerHTML = 'Zapri';
        closeButton.classList.add('absolute', 'top-2', 'right-2', 'bg-white', 'text-black', 'px-2', 'py-1',
            'rounded-md', 'cursor-pointer');
        closeButton.addEventListener('click', function() {
            overlay.remove();
        });

        // Create the full-size image
        const fullImage = document.createElement('img');
        fullImage.src = imageUrl;
        fullImage.alt = 'Full Image';
        fullImage.classList.add('m-auto');

        // Calculate maximum width and height based on viewport dimensions
        const maxViewportWidth = window.innerWidth * 0.9; // Adjust the multiplier as needed
        const maxViewportHeight = window.innerHeight * 0.9; // Adjust the multiplier as needed

        // Set the maximum width and height of the image
        fullImage.style.maxWidth = `${maxViewportWidth}px`;
        fullImage.style.maxHeight = `${maxViewportHeight}px`;

        // Append elements to the container
        container.appendChild(closeButton);
        container.appendChild(fullImage);

        // Append container to the overlay
        overlay.appendChild(container);

        // Append overlay to the body
        document.body.appendChild(overlay);
    }
</script>
<?php /**PATH C:\Users\Nejc Robič\Documents\Projects\Home\TenisTolmin\resources\views/components/carousel-gallery.blade.php ENDPATH**/ ?>