<div class="mt-6 text-center">
    <div class="bg-gray-200 rounded-lg shadow-lg p-4 mb-3 d-inline-block mx-auto w-80">
        <div class="mb-2">
            <img src="<?php echo e(asset('images/empty.png')); ?>" class="rounded-full h-16 w-16 mx-auto" alt="Model Image">
        </div>
        <h3 class="text-gray-800 text-lg font-bold mb-2"><?php echo e($model1); ?> prihajajo kmalu!!</h3>
    </div>
</div>
<?php /**PATH C:\Users\Nejc Robič\Documents\Projects\Home\TenisTolmin\resources\views/components/empty.blade.php ENDPATH**/ ?>