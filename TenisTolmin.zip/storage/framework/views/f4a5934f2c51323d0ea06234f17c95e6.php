<div class="container px-2 mx-auto py-8">
    <?php if($home): ?>
        <h1 class="text-3xl font-bold mb-3">Dogodki</h1>
        <h4 class="text-lg text-gray-600 mb-8"> V našem koledarju teniških dogodkov se združujemo ne samo zaradi
            tekmovanj, ampak tudi zaradi druženja in zabave. Od piknikov do delovnih akcij, naši dogodki ponujajo
            priložnost za srečanje, povezovanje in uživanje ob skupnih interesih izven igrišča.</h4>
    <?php endif; ?>
    
    <?php if($events->isEmpty()): ?>
        <?php if (isset($component)) { $__componentOriginal4f22a152e0729cd34293e65bd200d933 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4f22a152e0729cd34293e65bd200d933 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.empty','data' => ['model1' => 'Dogodki']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('empty'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['model1' => 'Dogodki']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4f22a152e0729cd34293e65bd200d933)): ?>
<?php $attributes = $__attributesOriginal4f22a152e0729cd34293e65bd200d933; ?>
<?php unset($__attributesOriginal4f22a152e0729cd34293e65bd200d933); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4f22a152e0729cd34293e65bd200d933)): ?>
<?php $component = $__componentOriginal4f22a152e0729cd34293e65bd200d933; ?>
<?php unset($__componentOriginal4f22a152e0729cd34293e65bd200d933); ?>
<?php endif; ?>
    <?php endif; ?>
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
        <!-- Event items -->
        <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div>
                <a href="<?php echo e(route('events_detail', $event['id'])); ?>">
                    <div
                        class="bg-gray-100 rounded-lg shadow-md overflow-hidden transition duration-300 ease-in-out transform hover:-translate-y-1 flex">
                        <div class="bg-gray-900 text-white w-16 flex justify-center items-center">
                            <img src="<?php echo e(asset('images/calandar.svg')); ?>" alt="Calendar Icon"
                                class="h-6 w-6 text-white" />
                        </div>
                        <div class="p-6">
                            <h2 class="text-xl font-semibold mb-4 text-gray-800"><?php echo e($event['e_title']); ?></h2>
                            <div class="flex items-center">
                                <div class="bg-gray-900 text-white px-3 py-1 rounded-full mr-2">
                                    <span class="font-bold"><?php echo e(date('d.m.Y', strtotime($event['fromDate']))); ?></span>
                                    <span class="mx-1 text-gray-400">|</span>
                                    <span class="font-bold"><?php echo e(date('H:i', strtotime($event['fromDate']))); ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <?php if($home): ?>
        <div class="flex justify-center mt-12">
            <a href="<?php echo e(route('events')); ?>"
                class="bg-gray-900 hover:bg-gray-800 text-white text-lg font-bold py-2 px-6 rounded-lg transition duration-300 ease-in-out transform hover:-translate-y-1">
                Več dogodkov
            </a>
        </div>
    <?php else: ?>
        <div class="mt-8"><?php echo e($events->links()); ?></div>
    <?php endif; ?>
</div>
<?php /**PATH C:\Users\Nejc Robič\Documents\Projects\Home\TenisTolmin\resources\views\partials\_events.blade.php ENDPATH**/ ?>