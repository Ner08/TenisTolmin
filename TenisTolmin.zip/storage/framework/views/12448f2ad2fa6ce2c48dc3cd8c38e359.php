<div class="bg-gray-200 shadow-inner">
    <div
        class="pb-4 pt-5 md:pt-3 text-gray-900 text-2xl font-bold items-center justify-between max-w-screen-2xl flex flex-wrap mx-auto p-3">
        <h1 class="underline "><?php echo e($title); ?></h1>
    </div>
</div>
<?php /**PATH C:\Users\Nejc Robič\Documents\Projects\Home\TenisTolmin\resources\views\components\title.blade.php ENDPATH**/ ?>