<?php $__currentLoopData = $brackets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bracket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
        $lastRound = $bracket->matchUps->max('round');
        $roundTitles = [
            1 => ['1.Kolo'],
            2 => ['1.Kolo', '2.Kolo'],
            3 => ['1.Kolo', '2.Kolo', '3.Kolo'],
            4 => ['1.Kolo', '2.Kolo', '3.Kolo', '4.Kolo'],
            5 => ['1.Kolo', '2.Kolo', '3.Kolo', '4.Kolo', '5.Kolo'],
            6 => ['1.Kolo', '2.Kolo', '3.Kolo', '4.Kolo', '5.Kolo', '6.Kolo'],
            7 => ['1.Kolo', '2.Kolo', '3.Kolo', '4.Kolo', '5.Kolo', '6.Kolo', '7.Kolo'],
            8 => ['1.Kolo', '2.Kolo', '3.Kolo', '4.Kolo', '5.Kolo', '6.Kolo', '7.Kolo', '8.Kolo'],
            9 => ['1.Kolo', '2.Kolo', '3.Kolo', '4.Kolo', '5.Kolo', '6.Kolo', '7.Kolo', '7.Kolo', '9.Kolo'],
        ];
    ?>

    <div class="p-4 pl-12 bg-gray-300">
        <h2 class="text-gray-900 font-bold text-2xl"><?php echo e($bracket->name); ?></h2>
    </div>

    

    <div class="overflow-x-auto border-gray-100 border-8 ">
        <table class="w-full bg-white shadow-md  overflow-hidden divide-y divide-gray-200 pb-4">
            <thead class="bg-gray-50 ">
                <tr>
                    <th scope="col"
                        class="px-2 sm:px-3 py-1 sm:py-3 text-center text-sm sm:text-base font-semibold text-gray-700 uppercase tracking-wider">
                        Oznaka
                    </th>
                    <th scope="col"
                        class="px-2 sm:px-3 py-1 sm:py-3 text-center text-sm sm:text-base font-semibold text-gray-700 uppercase tracking-wider">
                        Ime
                    </th>
                    <th scope="col"
                        class="px-2 sm:px-3 py-1 sm:py-3 text-center text-sm sm:text-base font-semibold text-gray-700 uppercase tracking-wider">
                        Št. Tekem
                    </th>
                    <th scope="col"
                        class="px-2 sm:px-3 py-1 sm:py-3 text-center text-sm sm:text-base font-semibold text-gray-700 uppercase tracking-wider">
                        D/I Seti
                    </th>
                    <th scope="col"
                        class="px-2 sm:px-3 py-1 sm:py-3 text-center text-sm sm:text-base font-semibold text-gray-700 uppercase tracking-wider">
                        D/I Gemi
                    </th>
                    <th scope="col"
                        class="px-2 sm:px-3 py-1 sm:py-3 text-center text-sm sm:text-base font-semibold text-gray-700 uppercase tracking-wider">
                        točke
                    </th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-200">
                <?php
                    // Sort the teams by multiple criteria
                    $sortedTeams = $bracket->teams->where('is_fake', false)->sortByDesc(function ($team) {
                        // Sort by group points first
                        $points = $team->group_points();
                        // Then by group set delta
                        $setDelta = $team->group_set_delta();
                        // Finally by group game delta
                        $gameDelta = $team->group_game_delta();
                        // Combine all criteria into a single value for sorting
                        return [$points, $setDelta, $gameDelta];
                    });
                ?>
                <?php $__currentLoopData = $sortedTeams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $p1 = $team->player1;
                        $p2 = $team->player2;
                        $team_name = isset($team->name)
                            ? $team->name . '<span class="text-blue-500"> (' . $p1->ranking() . ')</span>'
                            : (isset($p2)
                                ? $p1->p_name .
                                    '<span class="text-blue-500"> (' .
                                    $p1->ranking() .
                                    ')</span> | ' .
                                    $p2->p_name .
                                    '<span class="text-blue-500"> (' .
                                    $p2->ranking() .
                                    ')</span>'
                                : $p1->p_name);

                        $t1_ranking = ($p1->ranking() ?? '') . (isset($p2) ? '-' . $p2->ranking() : '');
                        // Calculate total points for the team
                    ?>
                    <tr class="hover:bg-gray-100">
                        <td class="px-2 sm:px-3 py-2 sm:py-4 whitespace-nowrap text-center text-xs">
                            <?php echo $bracket->tag . $loop->iteration; ?>

                        </td>
                        <td class="px-2 sm:px-3 py-2 sm:py-4 whitespace-nowrap text-center text-xs">
                            <?php echo $team_name; ?>

                        </td>
                        <td class="px-2 sm:px-3 py-2 sm:py-4 whitespace-nowrap text-center text-sm">
                            <?php echo e($team->matchups->count()); ?>

                        </td>
                        <td class="px-2 sm:px-3 py-2 sm:py-4 whitespace-nowrap text-center text-sm">
                            <?php echo e($team->group_set_delta()); ?>

                        </td>
                        <td class="px-2 sm:px-3 py-2 sm:py-4 whitespace-nowrap text-center text-sm">
                            <?php echo e($team->group_game_delta()); ?>

                        </td>
                        <td class="px-2 sm:px-3 py-2 sm:py-4 whitespace-nowrap text-center text-sm">
                            <?php echo e($team->group_points()); ?>

                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>


    <?php $__currentLoopData = $bracket->matchUps->sortBy('round')->groupBy('round'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $match): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="p-2 pl-12 w-full bg-gray-200">
            <h2 class="text-gray-900 font-bold text-lg"><?php echo e($roundTitles[$lastRound][$key - 1]); ?></h2>
        </div>
        <div class="grid grid-cols-1 gap-1 my-5">
            <?php $__currentLoopData = $bracket->matchUps->where('round', $key); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $match): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="bg-gray-100 rounded-md overflow-hidden shadow-md mx-4 mb-2">
                    <div class="bg-gray-200 p-2 grid grid-cols-2 gap-4">
                        <?php
                            $team1 = App\Models\Team::where('id', $match->team1_id)->first();
                            $t1p1 = $team1->player1;
                            $t1p2 = $team1->player2;
                            $team2 = App\Models\Team::where('id', $match->team2_id)->first();
                            $t2p1 = $team2->player1;
                            $t2p2 = $team2->player2;

                            $t1_name =
                                isset($t1p2) ? ($t1p1->p_name . ' | ' . $t1p2->p_name) : $t1p1->p_name;
                            $t2_name =
                                isset($t2p2) ? ($t2p1->p_name . ' | ' . $t2p2->p_name) : $t2p1->p_name;

                            $t1_ranking = ($t1p1->ranking() ?? '') . (isset($t1p2) ? '-' . $t1p2->ranking() : '');
                            $t2_ranking = ($t2p1->ranking() ?? '') . (isset($t2p2) ? '-' . $t2p2->ranking() : '');

                            $winner = $match->winner() ?? null;

                            $t1_sets_won = $match->t1SetsWon();
                            $t2_sets_won = $match->t2SetsWon();
                        ?>
                        <div
                            class="text-center border-r border-gray-400 pr-4 flex flex-col justify-center items-center">
                            <p class="font-semibold mb-2"><?php echo e($t1_name); ?> <span
                                    class="text-blue-500">(<?php echo e($t1_ranking); ?>)</span></p>
                            <?php if(isset($t1_sets_won)): ?>
                                <div class="flex items-center justify-center">
                                    <div class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                                        'text-white' => isset($winner),
                                        'px-4',
                                        'py-2',
                                        'rounded-full',
                                        'bg-green-600' => isset($winner) && $winner,
                                        'bg-red-600' => isset($winner) && !$winner,
                                        'font-semibold',
                                        'text-gray-100' => isset($winner),
                                    ]); ?>">
                                        <p><?php echo e($t1_sets_won); ?></p>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="text-center pl-4 flex flex-col justify-center items-center">
                            <p class="font-semibold mb-2"><?php echo e($t1_name); ?> <span
                                    class="text-blue-500">(<?php echo e($t2_ranking); ?>)</span></p>
                            <?php if(isset($t2_sets_won)): ?>
                                <div class="flex items-center justify-center">
                                    <div class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                                        'text-white' => isset($winner),
                                        'px-4',
                                        'py-2',
                                        'rounded-full',
                                        'bg-green-600' => isset($winner) && !$winner,
                                        'bg-red-600' => isset($winner) && $winner,
                                        'font-semibold',
                                        'text-gray-100' => isset($winner),
                                    ]); ?>">
                                        <p><?php echo e($t2_sets_won); ?></p>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php if(isset($match->endResult)): ?>
                        <?php if(isset($match->exception)): ?>
                            <div
                                class="text-center bg-gray-600 text-gray-200 rounded-b-md font-semibold items-center pb-1">
                                <?php echo e($match->exception); ?></div>
                        <?php elseif(isset($match->endResult)): ?>
                            <div
                                class="text-center bg-gray-600 text-gray-200 rounded-b-md font-semibold items-center pb-1">
                                <?php echo e($match->endResult); ?></div>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\Users\Nejc Robič\Documents\Projects\Home\TenisTolmin\resources\views\partials\_sm_league_group_stage.blade.php ENDPATH**/ ?>