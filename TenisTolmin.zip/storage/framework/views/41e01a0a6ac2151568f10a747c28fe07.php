<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => ['message' => $message ?? null,'flash' => $flash ?? null,'model' => $model ?? null]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['message' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($message ?? null),'flash' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($flash ?? null),'model' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($model ?? null)]); ?>
    <div class="bg-gray-200 pb-5">
        <div class="container mx-auto pt-4 px-4">
            <div class="bg-zinc-900 text-white py-2 px-4 rounded-t-lg">
                <h2 class="text-xl font-bold">Uredi igro</h2>
            </div>
            <form action="<?php echo e(route('leagues.matchup_edit', ['customMatchup' => $matchup->id])); ?>" method="POST" class="bg-gray-100 rounded-lg p-6">
                <?php echo method_field('PUT'); ?>
                <?php echo csrf_field(); ?>
                <!-- Team 1 Inputs -->
                <div class="mb-4">
                    <input type="hidden" name="bracket_id" value="<?php echo e($bracket->id); ?>">
                    <label for="teams" class="block text-gray-700 font-semibold mb-2">Igralec / Ekipa 1:</label>
                    <div>
                        <!-- Team 1 ID -->
                        <select name="team1_id"
                            class="form-select rounded-lg w-full focus:outline-none focus:border-blue-500 border-gray-300 py-3 px-4 mt-3">
                            <option disabled required>Izberite ekipo</option>
                            <!-- Use foreach to generate dropdown options for players -->
                            <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($team->id); ?>" <?php if($team->id == $matchup->team1_id): ?> selected <?php endif; ?>>
                                    <?php echo e($team->playerNames()); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['team1_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <!-- Oznaka for non-group stage -->
                    <?php if(!$bracket->is_group_stage): ?>
                        <label for="t1_tag"
                            class="block bg-gray-400 text-white font-semibold text-sm py-1 mb-0 px-4 mt-3 rounded-b-none rounded-lg">Oznaka</label>
                        <input type="text" name="t1_tag"
                            class="form-input w-full focus:outline-none border-gray-300 py-2 px-4 mt-0 rounded-t-none rounded-lg"
                            placeholder="Oznaka igralca / ekipe" value="<?php echo e($matchup->t1_tag); ?>"/>
                        <?php $__errorArgs = ['t1_tag'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <?php endif; ?>
                </div>

                <!-- Team 2 Inputs -->
                <div class="mb-4">
                    <label for="teams" class="block text-gray-700 font-semibold mb-2">Igralec / Ekipa 2:</label>
                    <div>
                        <!-- Team 2 ID -->
                        <select name="team2_id"
                            class="form-select rounded-lg w-full focus:outline-none focus:border-blue-500 border-gray-300 py-3 px-4 mt-3">
                            <option disabled required>Izberite ekipo</option>
                            <!-- Use foreach to generate dropdown options for players -->
                            <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($team->id); ?>" <?php if($team->id == $matchup->team2_id): ?> selected <?php endif; ?>>
                                    <?php echo e($team->playerNames()); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['team2_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            
                            <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <!-- Oznaka for non-group stage -->
                    <?php if(!$bracket->is_group_stage): ?>
                        <label for="t2_tag"
                            class="block bg-gray-400 text-white font-semibold text-sm py-1 mb-0 px-4 mt-3 rounded-b-none rounded-lg">Oznaka</label>
                        <input type="text" name="t2_tag"
                            class="form-input w-full focus:outline-none border-gray-300 py-2 px-4 mt-0 rounded-t-none rounded-lg"
                            placeholder="Oznaka igralca / ekipe" value="<?php echo e($matchup->t2_tag); ?>"/>
                        <?php $__errorArgs = ['t2_tag'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <?php endif; ?>
                </div>


                <label for="t1_first_set" class="block text-gray-700 font-semibold mb-2">1. Set:</label>
                <!--Score input -->
                <div class="mb-4 grid grid-cols-2 gap-4">
                    <div>
                        <input type="number" name="t1_first_set"
                            class="form-input rounded-lg w-full focus:outline-none focus:border-blue-500 border-gray-300 py-3 px-4 mt-3"
                            placeholder="Ekipa/igralec 1 prvi set" value="<?php echo e($matchup->t1_first_set); ?>"/>
                    </div>
                    <div>
                        <input type="number" name="t2_first_set"
                            class="form-input rounded-lg w-full focus:outline-none focus:border-blue-500 border-gray-300 py-3 px-4 mt-3"
                            placeholder="Ekipa/igralec 2 prvi set" value="<?php echo e($matchup->t2_first_set); ?>"/>
                    </div>
                </div>
                <?php $__errorArgs = ['t1_first_set'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <?php $__errorArgs = ['t2_first_set'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <label for="t1_first_set" class="block text-gray-700 font-semibold mb-2">2. Set:</label>
                <div class="mb-4 grid grid-cols-2 gap-4">
                    <div>
                        <input type="number" name="t1_second_set"
                            class="form-input rounded-lg w-full focus:outline-none focus:border-blue-500 border-gray-300 py-3 px-4 mt-3"
                            placeholder="Ekipa/igralec 1 drugi set" value="<?php echo e($matchup->t1_second_set); ?>"/>
                    </div>
                    <div>
                        <input type="number" name="t2_second_set"
                            class="form-input rounded-lg w-full focus:outline-none focus:border-blue-500 border-gray-300 py-3 px-4 mt-3"
                            placeholder="Ekipa/igralec 2 drugi set" value="<?php echo e($matchup->t2_second_set); ?>"/>
                    </div>
                </div>
                <?php $__errorArgs = ['t1_second_set'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <?php $__errorArgs = ['t2_second_set'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <label for="t1_first_set" class="block text-gray-700 font-semibold mb-2">3. Set:</label>
                <div class="mb-4 grid grid-cols-2 gap-4">
                    <div>
                        <input type="number" name="t1_third_set" min="0"
                            class="form-input rounded-lg w-full focus:outline-none focus:border-blue-500 border-gray-300 py-3 px-4 mt-3"
                            placeholder="Ekipa/igralec 1 tretji set" value="<?php echo e($matchup->t1_third_set); ?>"/>
                    </div>
                    <div>
                        <input type="number" name="t2_third_set" min="0"
                            class="form-input rounded-lg w-full focus:outline-none focus:border-blue-500 border-gray-300 py-3 px-4 mt-3"
                            placeholder="Ekipa/igralec 2 tretji set" value="<?php echo e($matchup->t2_third_set); ?>"/>
                    </div>
                </div>
                <?php $__errorArgs = ['t1_third_set'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <?php $__errorArgs = ['t2_third_set'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="mb-4">
                    <label for="exception" class="block text-gray-700 font-semibold mb-2">Besedilo po meri</label>
                    <input type="text" name="exception"
                        class="form-input rounded-lg w-full focus:outline-none focus:border-blue-500 border-gray-300 py-3 px-4 mt-3"
                        placeholder="Vnesi besedilo (Prepiše skupni rezultat) Primer: Brez boja " value="<?php echo e($matchup->exception); ?>"/>
                </div>
                <?php $__errorArgs = ['exception'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="mb-4 grid grid-cols-2 gap-4">
                    <div>
                        <label for="round" class="block text-gray-700 font-semibold mb-2">Runda:</label>
                        <input type="number" name="round" min="1" max="9"
                            class="form-input rounded-lg w-full focus:outline-none focus:border-blue-500 border-gray-300 py-3 px-4 mt-3"
                            placeholder="Vnesi rundo (v katerem krogu bo igra potekala)" value="<?php echo e($matchup->round); ?>"/>
                    </div>
                </div>
                <?php $__errorArgs = ['round'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <!-- Submit Button -->
                <button type="submit"
                    class="bg-zinc-500 text-white px-8 py-3 rounded-lg hover:bg-zinc-600 focus:outline-none transition duration-300 mt-2">Shrani</button>
            </form>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Nejc Robič\Documents\Projects\Home\TenisTolmin\resources\views\admin\matchup_edit.blade.php ENDPATH**/ ?>