<div class="container mx-auto py-8 px-4">
    <h1 class="text-3xl font-bold mb-3">Lige in turnirji</h1>
    <h4 class="text-lg text-gray-600 mb-8">V naši teniški ligi se igralci spodadamo v razburljivih tekmah, bodisi v
        dvojicah ali posamično. Ne glede na to, ali tekmuješ v paru ali sam, vsak turnir je priložnost za strastno
        tekmovanje in gradnjo športnih vezi.</h4>
    
    <?php if($leagues->isEmpty()): ?>
        <?php if (isset($component)) { $__componentOriginal4f22a152e0729cd34293e65bd200d933 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4f22a152e0729cd34293e65bd200d933 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.empty','data' => ['model1' => 'Lige in turnirji']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('empty'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['model1' => 'Lige in turnirji']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4f22a152e0729cd34293e65bd200d933)): ?>
<?php $attributes = $__attributesOriginal4f22a152e0729cd34293e65bd200d933; ?>
<?php unset($__attributesOriginal4f22a152e0729cd34293e65bd200d933); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4f22a152e0729cd34293e65bd200d933)): ?>
<?php $component = $__componentOriginal4f22a152e0729cd34293e65bd200d933; ?>
<?php unset($__componentOriginal4f22a152e0729cd34293e65bd200d933); ?>
<?php endif; ?>
    <?php endif; ?>
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        <?php $__currentLoopData = $leagues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $league): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('league', $league->id)); ?>"
                class="bg-gray-100 hover:bg-gray-200 cursor-pointer rounded-lg shadow-md overflow-hidden transition duration-300 ease-in-out transform hover:-translate-y-1">
                <div class="flex flex-col h-full">
                    <div class="p-6 pb-3 flex-grow">
                        <h3 class="text-xl font-semibold mb-4 text-gray-800"><?php echo e($league->name); ?></h3>
                        <p class="text-gray-600 mb-6"><?php echo e($league->description); ?></p>
                    </div>
                    <div class="py-3 px-6 flex justify-between items-center text-gray-300 bg-gray-900">
                        <div>
                            <p class="flex items-center">
                                <img src="/images/from.svg" class="w-4 h-4 mr-2" alt="From Icon">
                                <span class="text-sm font-medium">
                                    <?php echo e(\Carbon\Carbon::parse($league->start_date)->format('d.m.Y')); ?></span>
                            </p>
                        </div>
                        <?php if($league->end_date): ?>
                            <div class="ml-auto">
                                <p class="flex items-center">
                                    <img src="/images/to.svg" class="w-4 h-4 mr-2" alt="To Icon">
                                    <span class="text-sm font-medium">
                                        <?php echo e(\Carbon\Carbon::parse($league->end_date)->format('d.m.Y')); ?></span>
                                </p>
                            </div>
                        <?php else: ?>
                            <div class="ml-auto">
                                <p class="flex items-center">
                                    <img src="/images/to.svg" class="w-4 h-4 mr-2" alt="To Icon">
                                    <span class="text-sm font-medium">Ni določen</span>
                                </p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="flex justify-center mt-12 gap-2">
        <a href="<?php echo e(route('leagues')); ?>"
            class="bg-gray-900 hover:bg-gray-800 text-center text-white text-lg font-bold py-2 px-6 rounded-lg transition duration-300 ease-in-out transform hover:-translate-y-1">
            Več lig in turnirjev
        </a>
        <a href="<?php echo e(route('scoreboard')); ?>"
            class="bg-gray-900 hover:bg-gray-800 text-center text-white text-lg font-bold py-2 px-6 rounded-lg transition duration-300 ease-in-out transform hover:-translate-y-1">
            Tminska ATP lestvica
        </a>
    </div>
</div>
<?php /**PATH C:\Users\Nejc Robič\Documents\Projects\Home\TenisTolmin\resources\views/partials/_leagues.blade.php ENDPATH**/ ?>