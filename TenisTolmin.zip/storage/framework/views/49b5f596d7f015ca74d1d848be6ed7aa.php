<div>
    <a href="<?php echo e(route('news_detail', $item['id'])); ?>">
        <div
            class="block bg-gray-100 hover:bg-gray-200 rounded-lg shadow-md cursor-pointer transition duration-300 ease-in-out transform hover:-translate-y-1">
            <?php if(isset($item['image'])): ?>
                <div class="relative overflow-hidden rounded-t-lg">
                    <img src="<?php echo e(route('storage.show', ['filename' => $item['image']])); ?>" alt="<?php echo e($item['title']); ?>"
                        class="w-full h-64 object-cover">
                    <div class="absolute inset-0 bg-gray-900 opacity-25"></div>
                </div>
                <div class="p-6 flex flex-col justify-between">
                    <div class="overflow-hidden">
                        <h2 class="text-xl font-semibold mb-2"><?php echo e($item['title']); ?></h2>
                        <p class="text-gray-700 line-clamp-3"><?php echo $item['content']; ?></p>
                    </div>
                    <p class="text-gray-600 mt-2 text-right"><?php echo e($item['created_at']->format('d.m.Y')); ?></p>
                </div>
            <?php else: ?>
                <div class="p-6 flex flex-col justify-between">
                    <div class="overflow-hidden">
                        <h2 class="text-xl font-semibold mb-2"><?php echo e($item['title']); ?></h2>
                        <p class="text-gray-700"><?php echo e(Str::limit($item['content'], 650)); ?></p>
                    </div>
                    <p class="text-gray-600 mt-2 text-right"><?php echo e($item['created_at']->format('d.m.Y')); ?></p>
                </div>
            <?php endif; ?>
        </div>
    </a>
</div>



<?php /**PATH C:\Users\Nejc Robič\Documents\Projects\Home\TenisTolmin\resources\views\partials\_news_item.blade.php ENDPATH**/ ?>