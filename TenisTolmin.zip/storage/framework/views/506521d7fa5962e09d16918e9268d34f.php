<?php $__currentLoopData = $brackets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bracket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
        $lastRound = $bracket->matchUps->max('round') ?? 10;
        $roundTitles = [
            1 => ['Finale'],
            2 => ['Polfinale', 'Finale'],
            3 => ['Četrtfinale', 'Polfinale', 'Finale'],
            4 => ['Osminafinala', 'Četrtfinale', 'Polfinale', 'Finale'],
            5 => ['1.Krog', 'Osminafinala', 'Četrtfinale', 'Polfinale', 'Finale'],
            6 => ['1.Krog', '2.Krog', 'Osminafinala', 'Četrtfinale', 'Polfinale', 'Finale'],
            7 => ['1.Krog', '2.Krog', '3.Krog', 'Osminafinala', 'Četrtfinale', 'Polfinale', 'Finale'],
            8 => ['1.Krog', '2.Krog', '3.Krog', '4.Krog', 'Osminafinala', 'Četrtfinale', 'Polfinale', 'Finale'],
            9 => [
                '1.Krog',
                '2.Krog',
                '3.Krog',
                '4.Krog',
                '5.Krog',
                'Osminafinala',
                'Četrtfinale',
                'Polfinale',
                'Finale',
            ],
            10 => ['Tekme še niso določene.'],
        ];
    ?>

    <div class="p-3 pl-12 bg-gray-700">
        <h2 class="text-gray-200 font-bold text-xl"><?php echo e($bracket->name); ?></h2>
    </div>
    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-5">
        <?php $__currentLoopData = $bracket->matchUps->sortBy('round')->groupBy('round'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $match): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="p-1 pl-12 bg-gray-200">
                <h2 class="text-gray-900 font-bold text-lg"><?php echo e($roundTitles[$lastRound][$key - 1]); ?></h2>
            </div>
            <?php $__currentLoopData = $bracket->matchUps->where('round', $key); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $match): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="bg-gray-100 rounded-md overflow-hidden shadow-md mx-4">
                    <div class="bg-gray-200 p-4 grid grid-cols-2 gap-4">
                        <?php
                            $team1 = App\Models\Team::where('id', $match->team1_id)->first();
                            $t1p1 = $team1->player1;
                            $t1p2 = $team1->player2;
                            $team2 = App\Models\Team::where('id', $match->team2_id)->first();
                            $t2p1 = $team2->player1;
                            $t2p2 = $team2->player2;

                            $t1_name = isset($t1p2) ? $t1p1->p_name . ' | ' . $t1p2->p_name : $t1p1->p_name;
                            $t2_name = isset($t2p2) ? $t2p1->p_name . ' | ' . $t2p2->p_name : $t2p1->p_name;

                            $t1_ranking = ($t1p1->ranking() ?? '') . (isset($t1p2) ? '-' . $t1p2->ranking() : '');
                            $t2_ranking = ($t2p1->ranking() ?? '') . (isset($t2p2) ? '-' . $t2p2->ranking() : '');

                            $winner = $match->winner() ?? null;

                            $t1_sets_won = $match->t1SetsWon();
                            $t2_sets_won = $match->t2SetsWon();
                        ?>
                        <div class="text-center border-r border-gray-400 pr-4 flex flex-col justify-between">
                            <div>
                                <?php if($match->t1_tag): ?>
                                    <div
                                        class="inline-block bg-gray-900 text-white px-3 py-1 font-semibold text-sm rounded-md mx-1 mb-2">
                                        <?php echo e($match->t1_tag); ?>

                                    </div>
                                <?php endif; ?>
                                <?php if(isset($t2_name)): ?>
                                    <?php if(!isset($match->t1_tag) && $team1->is_fake): ?>
                                        <div>
                                            <p class="font-semibold text-sm"><?php echo e($t1_name); ?></p>
                                        </div>
                                    <?php elseif(isset($match->t1_tag) && $team1->is_fake): ?>

                                    <?php elseif(!$team1->is_fake): ?>
                                        <p class="font-semibold mb-3"><?php echo e($t1_name); ?> <span
                                                class="text-blue-500">(<?php echo e($t1_ranking); ?>)</span></p>
                                        <!-- Player 1 content here -->
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                            <div class="text-center">
                                <?php if(isset($t1_sets_won)): ?>
                                    <div class="flex items-center justify-center">
                                        <div class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                                            'text-white' => isset($winner),
                                            'px-4',
                                            'py-2',
                                            'rounded-full',
                                            'bg-green-600' => isset($winner) && $winner,
                                            'bg-red-600' => isset($winner) && !$winner,
                                            'font-semibold',
                                            'text-gray-100' => isset($winner),
                                        ]); ?>">
                                            <p><?php echo e($t1_sets_won); ?></p>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="text-center pl-4 flex flex-col justify-between">
                            <div>
                                <?php if($match->t2_tag): ?>
                                    <div
                                        class="inline-block bg-gray-900 text-white px-3 py-1 font-semibold text-sm rounded-md mx-1 mb-2">
                                        <?php echo e($match->t2_tag); ?>

                                    </div>
                                <?php endif; ?>
                                <?php if(isset($t2_name)): ?>
                                    <?php if(!isset($match->t2_tag) && $team2->is_fake): ?>
                                        <div>
                                            <p class="font-semibold text-sm"><?php echo e($t1_name); ?></p>
                                        </div>
                                    <?php elseif(isset($match->t2_tag) && $team2->is_fake): ?>

                                    <?php elseif(!$team2->is_fake): ?>
                                        <p class="font-semibold mb-3"><?php echo e($t2_name); ?> <span
                                                class="text-blue-500">(<?php echo e($t2_ranking); ?>)</span></p>
                                        <!-- Player 1 content here -->
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                            <div class="text-center">
                                <?php if(isset($t2_sets_won)): ?>
                                    <div class="flex items-center justify-center">
                                        <div class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                                            'text-white' => isset($winner),
                                            'px-4',
                                            'py-2',
                                            'rounded-full',
                                            'bg-green-600' => isset($winner) && !$winner,
                                            'bg-red-600' => isset($winner) && $winner,
                                            'font-semibold',
                                            'text-gray-100' => isset($winner),
                                        ]); ?>">
                                            <p><?php echo e($t2_sets_won); ?></p>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <?php if(isset($match->exception)): ?>
                        <div class="text-center bg-gray-600 text-gray-200 rounded-b-md font-semibold items-center pb-1">
                            <?php echo e($match->exception); ?></div>
                    <?php elseif(isset($match->endResult)): ?>
                        <div class="text-center bg-gray-600 text-gray-200 rounded-b-md font-semibold items-center pb-1">
                            <?php echo e($match->endResult); ?></div>
                    <?php endif; ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php if(isset($bracket->points_description)): ?>
            <div class="px-4 mx-auto max-w-xl">
                <div class="bg-gray-12514++
                00 rounded-lg p-4 shadow-md">
                    <p class="text-gray-700 leading-relaxed"><?php echo e($bracket->points_description); ?></p>
                </div>
            </div>
        <?php endif; ?>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\Users\Nejc Robič\Documents\Projects\Home\TenisTolmin\resources\views\components\sm-screen-leagues.blade.php ENDPATH**/ ?>