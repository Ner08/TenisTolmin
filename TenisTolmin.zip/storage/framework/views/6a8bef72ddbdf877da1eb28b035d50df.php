<h1><?php echo e($name); ?></h1>

<h2>HELO</h2>
<?php /**PATH C:\Users\robic\Projects\TenisTolmin\resources\views/mail/test-email.blade.php ENDPATH**/ ?>