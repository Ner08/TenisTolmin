<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div>
        <?php if($isMobile): ?>
            <?php if (isset($component)) { $__componentOriginal683da48c5329eaa2bf093c307b23017f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal683da48c5329eaa2bf093c307b23017f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sm-league-title','data' => ['data' => ['name' => $league->name, 'start_date' => $league->start_date, 'end_date' => $league->end_date]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sm-league-title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['data' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(['name' => $league->name, 'start_date' => $league->start_date, 'end_date' => $league->end_date])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal683da48c5329eaa2bf093c307b23017f)): ?>
<?php $attributes = $__attributesOriginal683da48c5329eaa2bf093c307b23017f; ?>
<?php unset($__attributesOriginal683da48c5329eaa2bf093c307b23017f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal683da48c5329eaa2bf093c307b23017f)): ?>
<?php $component = $__componentOriginal683da48c5329eaa2bf093c307b23017f; ?>
<?php unset($__componentOriginal683da48c5329eaa2bf093c307b23017f); ?>
<?php endif; ?>
            <?php if($brackets->isNotEmpty()): ?>
                <?php if (isset($component)) { $__componentOriginal1f77f644d858d31499d18c32e8a0952c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1f77f644d858d31499d18c32e8a0952c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.league-group-title','data' => ['title' => 'Izločitveni del']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('league-group-title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Izločitveni del']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1f77f644d858d31499d18c32e8a0952c)): ?>
<?php $attributes = $__attributesOriginal1f77f644d858d31499d18c32e8a0952c; ?>
<?php unset($__attributesOriginal1f77f644d858d31499d18c32e8a0952c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1f77f644d858d31499d18c32e8a0952c)): ?>
<?php $component = $__componentOriginal1f77f644d858d31499d18c32e8a0952c; ?>
<?php unset($__componentOriginal1f77f644d858d31499d18c32e8a0952c); ?>
<?php endif; ?>
            <?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal4b80fdd227e3c40101eeb842e1c9558b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4b80fdd227e3c40101eeb842e1c9558b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sm-screen-leagues','data' => ['brackets' => $brackets]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sm-screen-leagues'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['brackets' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($brackets)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4b80fdd227e3c40101eeb842e1c9558b)): ?>
<?php $attributes = $__attributesOriginal4b80fdd227e3c40101eeb842e1c9558b; ?>
<?php unset($__attributesOriginal4b80fdd227e3c40101eeb842e1c9558b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4b80fdd227e3c40101eeb842e1c9558b)): ?>
<?php $component = $__componentOriginal4b80fdd227e3c40101eeb842e1c9558b; ?>
<?php unset($__componentOriginal4b80fdd227e3c40101eeb842e1c9558b); ?>
<?php endif; ?>
            <?php if($brackets_group->isNotEmpty()): ?>
                <?php if (isset($component)) { $__componentOriginal1f77f644d858d31499d18c32e8a0952c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1f77f644d858d31499d18c32e8a0952c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.league-group-title','data' => ['title' => 'Skupinski del']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('league-group-title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Skupinski del']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1f77f644d858d31499d18c32e8a0952c)): ?>
<?php $attributes = $__attributesOriginal1f77f644d858d31499d18c32e8a0952c; ?>
<?php unset($__attributesOriginal1f77f644d858d31499d18c32e8a0952c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1f77f644d858d31499d18c32e8a0952c)): ?>
<?php $component = $__componentOriginal1f77f644d858d31499d18c32e8a0952c; ?>
<?php unset($__componentOriginal1f77f644d858d31499d18c32e8a0952c); ?>
<?php endif; ?>
            <?php endif; ?>
            <?php if($brackets->isEmpty() && $brackets_group->isEmpty()): ?>
                <div class="m-6">
                    <div class="text-xl font-bold text-gray-700 bg-gray-300 p-4 rounded-lg inline-block">
                        Liga še ni nastavljena, mogoče pa se prikaže kmalu :)
                    </div>
                </div>
            <?php endif; ?>
            <?php echo $__env->make('partials._sm_league_group_stage', ['brackets' => $brackets_group], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php else: ?>
            <?php if (isset($component)) { $__componentOriginalfbfafcaa51968ff13e1cd7e2023e062c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfbfafcaa51968ff13e1cd7e2023e062c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.league-title','data' => ['data' => ['name' => $league->name, 'start_date' => $league->start_date, 'end_date' => $league->end_date]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('league-title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['data' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(['name' => $league->name, 'start_date' => $league->start_date, 'end_date' => $league->end_date])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfbfafcaa51968ff13e1cd7e2023e062c)): ?>
<?php $attributes = $__attributesOriginalfbfafcaa51968ff13e1cd7e2023e062c; ?>
<?php unset($__attributesOriginalfbfafcaa51968ff13e1cd7e2023e062c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfbfafcaa51968ff13e1cd7e2023e062c)): ?>
<?php $component = $__componentOriginalfbfafcaa51968ff13e1cd7e2023e062c; ?>
<?php unset($__componentOriginalfbfafcaa51968ff13e1cd7e2023e062c); ?>
<?php endif; ?>
            <?php if($brackets->isNotEmpty()): ?>
                <?php if (isset($component)) { $__componentOriginal1f77f644d858d31499d18c32e8a0952c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1f77f644d858d31499d18c32e8a0952c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.league-group-title','data' => ['title' => 'Izločitveni del']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('league-group-title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Izločitveni del']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1f77f644d858d31499d18c32e8a0952c)): ?>
<?php $attributes = $__attributesOriginal1f77f644d858d31499d18c32e8a0952c; ?>
<?php unset($__attributesOriginal1f77f644d858d31499d18c32e8a0952c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1f77f644d858d31499d18c32e8a0952c)): ?>
<?php $component = $__componentOriginal1f77f644d858d31499d18c32e8a0952c; ?>
<?php unset($__componentOriginal1f77f644d858d31499d18c32e8a0952c); ?>
<?php endif; ?>
            <?php endif; ?>
            <?php $__currentLoopData = $brackets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bracket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="p-2 pl-12 bg-gray-200">
                    <h1 class="p-2 inline-block text-gray-900 font-bold text-2xl"><?php echo e($bracket->name); ?></h1>
                </div>

                <div class="m-2 p-4 pb-0 bg-white rounded-xl">
                    <?php
                        $lastRound = $bracket->matchUps->max('round') ?? 10;
                        $roundTitles = [
                            1 => ['Finale'],
                            2 => ['Polfinale', 'Finale'],
                            3 => ['Četrtfinale', 'Polfinale', 'Finale'],
                            4 => ['Osminafinala', 'Četrtfinale', 'Polfinale', 'Finale'],
                            5 => ['1.Krog', 'Osminafinala', 'Četrtfinale', 'Polfinale', 'Finale'],
                            6 => ['1.Krog', '2.Krog', 'Osminafinala', 'Četrtfinale', 'Polfinale', 'Finale'],
                            7 => ['1.Krog', '2.Krog', '3.Krog', 'Osminafinala', 'Četrtfinale', 'Polfinale', 'Finale'],
                            8 => [
                                '1.Krog',
                                '2.Krog',
                                '3.Krog',
                                '4.Krog',
                                'Osminafinala',
                                'Četrtfinale',
                                'Polfinale',
                                'Finale',
                            ],
                            9 => [
                                '1.Krog',
                                '2.Krog',
                                '3.Krog',
                                '4.Krog',
                                '5.Krog',
                                'Osminafinala',
                                'Četrtfinale',
                                'Polfinale',
                                'Finale',
                            ],
                            10 => ['Tekme še niso določene.'],
                        ];

                        // Calculate the width of each column
                        $colWidth = 12 / $lastRound; // Divide 12 (the number of columns in Bootstrap grid system) by the total number of rounds
                    ?>

                    <div
                        class="mb-4 grid-flow-col items-center border-0 border-b-2 border-gray-200 text-center text-lg font-bold uppercase hidden md:grid">
                        <?php $__currentLoopData = $roundTitles[$lastRound]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $title): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="w-full md:w-auto md:flex-grow-0 md:w-<?php echo e($colWidth); ?>"><?php echo e($title); ?>

                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <div class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                        'grid',
                        'grid-flow-col',
                        'grid-cols-' . $lastRound,
                        'items-center',
                    ]); ?>">
                        <?php $__currentLoopData = $bracket->matchUps->sortBy('round')->groupBy('round'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $match): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                                'mx-2',
                                'h-1/' . 2 ** ($key + 1) => $key != 1,
                                'grid',
                                'grid-flow-row',
                                'grid-rows-' . ($lastRound - ($key - 1)),
                            ]); ?>">
                                <?php $__currentLoopData = $bracket->matchUps->where('round', $key); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $match): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $team1 = App\Models\Team::where('id', $match->team1_id)->first();
                                        $t1p1 = $team1->player1;
                                        $t1p2 = $team1->player2;
                                        $team2 = App\Models\Team::where('id', $match->team2_id)->first();
                                        $t2p1 = $team2->player1;
                                        $t2p2 = $team2->player2;

                                        $t1_name = isset($t1p2) ? $t1p1->p_name . ' | ' . $t1p2->p_name : $t1p1->p_name;
                                        $t2_name = isset($t2p2) ? $t2p1->p_name . ' | ' . $t2p2->p_name : $t2p1->p_name;

                                        $t1_ranking =
                                            ($t1p1->ranking() ?? '') . (isset($t1p2) ? '-' . $t1p2->ranking() : '');
                                        $t2_ranking =
                                            ($t2p1->ranking() ?? '') . (isset($t2p2) ? '-' . $t2p2->ranking() : '');

                                        $winner = $match->winner() ?? null;

                                        $t1_sets_won = $match->t1SetsWon();
                                        $t2_sets_won = $match->t2SetsWon();
                                    ?>
                                    <div class="mb-4 rounded-md bg-gray-200 pt-2 text-gray-900">
                                        <div class="flex justify-between items-center px-4">
                                            <?php if($match->t1_tag): ?>
                                                <div
                                                    class="bg-gray-900 text-white px-2 py-1 font-semibold text-sm rounded-md mr-4">
                                                    <?php echo e($match->t1_tag); ?></div>
                                            <?php endif; ?>
                                            <?php if(isset($t2_name)): ?>
                                                <?php if(!isset($match->t1_tag) && $team1->is_fake): ?>
                                                    <div>
                                                        <p class="font-semibold text-sm"><?php echo e($t1_name); ?></p>
                                                    </div>
                                                <?php elseif(isset($match->t1_tag) && $team1->is_fake): ?>

                                                <?php elseif(!$team1->is_fake): ?>
                                                    <div>
                                                        <p class="font-semibold text-sm"><?php echo e($t1_name); ?> <span
                                                                class="text-blue-500">(<?php echo e($t1_ranking); ?>)</span></p>
                                                    </div>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                            <?php if(isset($t1_sets_won)): ?>
                                                <div class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                                                    'text-white' => isset($winner),
                                                    'px-3',
                                                    'ml-2',
                                                    'py-1',
                                                    'rounded-full',
                                                    'bg-green-600' => isset($winner) && $winner,
                                                    'bg-red-600' => isset($winner) && !$winner,
                                                ]); ?>">
                                                    <p class="text-right"><?php echo e($t1_sets_won); ?></p>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                        <div class="flex justify-between items-center my-2 px-4 ">
                                            <?php if($match->t2_tag): ?>
                                                <div
                                                    class="bg-gray-900 text-white px-2 py-1 font-semibold text-sm rounded-md mr-4">
                                                    <?php echo e($match->t2_tag); ?></div>
                                            <?php endif; ?>
                                            <?php if(isset($t2_name)): ?>
                                                <?php if(!isset($match->t2_tag) && $team2->is_fake): ?>
                                                    <div>
                                                        <p class="font-semibold text-sm"><?php echo e($t2_name); ?></p>
                                                    </div>
                                                <?php elseif(isset($match->t2_tag) && $team2->is_fake): ?>

                                                <?php elseif(!$team2->is_fake): ?>
                                                    <div>
                                                        <p class="font-semibold text-sm"><?php echo e($t2_name); ?> <span
                                                                class="text-blue-500">(<?php echo e($t2_ranking); ?>)</span></p>
                                                    </div>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                            <?php if(isset($t2_sets_won)): ?>
                                                <div class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                                                    'text-white' => isset($winner),
                                                    'px-3',
                                                    'ml-2',
                                                    'py-1',
                                                    'rounded-full',
                                                    'bg-green-600' => isset($winner) && !$winner,
                                                    'bg-red-600' => isset($winner) && $winner,
                                                ]); ?>">
                                                    <p class="text-right"><?php echo e($t2_sets_won); ?></p>
                                                </div>
                                            <?php endif; ?>

                                        </div>
                                        <?php if(isset($match->exception)): ?>
                                            <div
                                                class="text-center bg-gray-600 text-gray-200 rounded-b-md font-semibold items-center pb-1">
                                                <?php echo e($match->exception); ?></div>
                                        <?php elseif(isset($match->endResult)): ?>
                                            <div
                                                class="text-center bg-gray-600 text-gray-200 rounded-b-md font-semibold items-center pb-1">
                                                <?php echo e($match->endResult); ?></div>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <?php if(isset($bracket->points_description)): ?>
                    <div class="m-3 mr-8 pb-4 flex justify-end">
                        <div class="bg-gray-100 rounded-lg p-4 shadow-md">
                            <p class="text-gray-700 leading-relaxed"><?php echo e($bracket->points_description); ?></p>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php if($brackets_group->isNotEmpty()): ?>
                <?php if (isset($component)) { $__componentOriginal1f77f644d858d31499d18c32e8a0952c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1f77f644d858d31499d18c32e8a0952c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.league-group-title','data' => ['title' => 'Skupinski del']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('league-group-title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Skupinski del']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1f77f644d858d31499d18c32e8a0952c)): ?>
<?php $attributes = $__attributesOriginal1f77f644d858d31499d18c32e8a0952c; ?>
<?php unset($__attributesOriginal1f77f644d858d31499d18c32e8a0952c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1f77f644d858d31499d18c32e8a0952c)): ?>
<?php $component = $__componentOriginal1f77f644d858d31499d18c32e8a0952c; ?>
<?php unset($__componentOriginal1f77f644d858d31499d18c32e8a0952c); ?>
<?php endif; ?>
            <?php endif; ?>
            <?php if($brackets->isEmpty() && $brackets_group->isEmpty()): ?>
                <div class="m-6">
                    <div class="text-xl font-bold text-gray-700 bg-gray-300 p-4 rounded-lg inline-block">
                        Liga še ni nastavljena, mogoče pa se prikaže kmalu :)
                    </div>
                </div>
            <?php endif; ?>
            <?php echo $__env->make('partials._league_group_stage', ['brackets' => $brackets_group], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Nejc Robič\Documents\Projects\Home\TenisTolmin\resources\views\leagues\show.blade.php ENDPATH**/ ?>