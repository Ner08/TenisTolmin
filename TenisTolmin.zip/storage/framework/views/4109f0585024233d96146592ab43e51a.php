<!doctype html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
    <script src="//unpkg.com/alpinejs" defer></script>
</head>

<body>
    <nav class=" border-gray-200 bg-gray-900 fixed w-full top-0 left-0 z-50">
        <div class="max-w-screen-2xl flex flex-wrap items-center justify-between mx-auto p-3">
            <a href="/" class="flex items-center space-x-3 rtl:space-x-reverse">
                <img src="<?php echo e(asset('images/logo10.png')); ?>" alt="logo" class="h-8 w-auto" />
                <span class="self-center text-2xl font-semibold whitespace-nowrap text-white">Teniški klub
                    Tolmin</span>

            </a>
            <button data-collapse-toggle="navbar-default" type="button" id="navbar-toggle"
                class="inline-flex items-center p-2 w-10 h-10 justify-center text-sm rounded-lg md:hidden focus:outline-none focus:ring-2  text-gray-400 hover:bg-gray-700 focus:ring-gray-600"
                aria-controls="navbar-default" aria-expanded="false">
                <span class="sr-only">Open main menu</span>
                <svg class="w-5 h-5" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none"
                    viewBox="0 0 17 14">
                    <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="M1 1h15M1 7h15M1 13h15" />
                </svg>
            </button>
            <span class="hidden w-full md:block md:w-auto" id="navbar-default">
                <ul
                    class="font-medium flex flex-col p-4 md:p-0 mt-4 border rounded-lg md:flex-row md:space-x-8 rtl:space-x-reverse md:mt-0 md:border-0 bg-gray-800 md:bg-gray-900 border-gray-700">
                    <li>
                        <a href="<?php echo e(route('news')); ?>"
                            class="block py-2 px-3 rounded md:border-0 md:p-0 text-white md:hover:text-gray-300 hover:bg-gray-700 hover:text-white md:hover:bg-transparent">Novice</a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('leagues')); ?>"
                            class="block py-2 px-3 rounded md:border-0 md:p-0 text-white md:hover:text-gray-300 hover:bg-gray-700 hover:text-white md:hover:bg-transparent">Lige</a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('gallery')); ?>"
                            class="block py-2 px-3 rounded  md:border-0 md:p-0 text-white md:hover:text-gray-300 hover:bg-gray-700 hover:text-white md:hover:bg-transparent">Galerija
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('events')); ?>"
                            class="block py-2 px-3 rounded md:border-0 md:p-0 text-white md:hover:text-gray-300 hover:bg-gray-700 hover:text-white md:hover:bg-transparent">Dogodki</a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('membership')); ?>"
                            class="block py-2 px-3 rounded md:border-0 md:p-0 text-white md:hover:text-gray-300 hover:bg-gray-700 hover:text-white md:hover:bg-transparent">Članstvo
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('contact')); ?>"
                            class="block py-2 px-3 rounded md:border-0 md:p-0 text-white md:hover:text-gray-300 hover:bg-gray-700 hover:text-white md:hover:bg-transparent">Kontakt</a>
                    </li>
                    <?php if(auth()->guard()->check()): ?>
                        <li>
                            <form action="<?php echo e(route('logout')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <button type="submit"
                                    class="block py-2 px-3 rounded md:border-0 md:p-0 text-white md:hover:text-gray-300 hover:bg-gray-700 hover:text-white md:hover:bg-transparent">
                                    Odjava
                                </button>
                            </form>
                        </li>
                    <?php endif; ?>
                </ul>
        </div>
        </span>
    </nav>

    <div class="mt-12 pt-2 <?php if(session()->has('flash') && session()->has('message')): ?> blurred <?php endif; ?>">
        <?php echo e($slot); ?>

    </div>

    
    <?php if(auth()->guard()->check()): ?>
        <?php if(auth()->user()->is_admin): ?>
            <div class="fixed bottom-4 right-4">
                <a href="<?php echo e(route('admin')); ?>"
                    class="flex items-center justify-center border-2 border-white w-16 h-16 bg-gray-900 hover:bg-gray-800 text-white font-bold rounded-full shadow-2xls">
                    Admin
                </a>
            </div>
        <?php endif; ?>
    <?php endif; ?>

    <?php if(session()->has('flash') && session()->has('message')): ?>
        <?php if (isset($component)) { $__componentOriginalbb0843bd48625210e6e530f88101357e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbb0843bd48625210e6e530f88101357e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.flash-message','data' => ['route' => $route ?? null,'flash' => $flash ?? null,'message' => $message ?? null,'model' => $model ?? null]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('flash-message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['route' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($route ?? null),'flash' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($flash ?? null),'message' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($message ?? null),'model' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($model ?? null)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbb0843bd48625210e6e530f88101357e)): ?>
<?php $attributes = $__attributesOriginalbb0843bd48625210e6e530f88101357e; ?>
<?php unset($__attributesOriginalbb0843bd48625210e6e530f88101357e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbb0843bd48625210e6e530f88101357e)): ?>
<?php $component = $__componentOriginalbb0843bd48625210e6e530f88101357e; ?>
<?php unset($__componentOriginalbb0843bd48625210e6e530f88101357e); ?>
<?php endif; ?>
    <?php elseif(session()->has('message')): ?>
        <?php if (isset($component)) { $__componentOriginal9bcb65a27ae6bfbb230c26838e738959 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9bcb65a27ae6bfbb230c26838e738959 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.flash-message-2','data' => ['message' => $message]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('flash-message-2'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['message' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($message)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9bcb65a27ae6bfbb230c26838e738959)): ?>
<?php $attributes = $__attributesOriginal9bcb65a27ae6bfbb230c26838e738959; ?>
<?php unset($__attributesOriginal9bcb65a27ae6bfbb230c26838e738959); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9bcb65a27ae6bfbb230c26838e738959)): ?>
<?php $component = $__componentOriginal9bcb65a27ae6bfbb230c26838e738959; ?>
<?php unset($__componentOriginal9bcb65a27ae6bfbb230c26838e738959); ?>
<?php endif; ?>
    <?php endif; ?>
</body>

<script>
    window.onload = function() {
        // Check if the page was reloaded (type === 1 indicates reload)
        if (performance.navigation.type === 1) {
            // Remove query parameters from the URL
            window.history.replaceState({}, document.title, window.location.pathname);
        } else {
            // If it's not a reload, keep the scroll position
            const scrollPosition = sessionStorage.getItem('scrollPosition');
            if (scrollPosition !== null) {
                window.scrollTo(0, scrollPosition);
                // Delete the scroll position from sessionStorage after scrolling to it
                sessionStorage.removeItem('scrollPosition');
            }
        }
    };

    document.addEventListener('DOMContentLoaded', function() {
        // Add event listener to form submission
        document.addEventListener('submit', function(event) {
            // Store the scroll position before the form is submitted
            sessionStorage.setItem('scrollPosition', window.scrollY);
        });
    });

    document.addEventListener('DOMContentLoaded', function() {
        const navbarToggle = document.getElementById('navbar-toggle');
        const navbarDefault = document.getElementById('navbar-default');

        navbarToggle.addEventListener('click', function() {
            navbarDefault.classList.toggle('hidden');
        });
    });

    function showDeleteConfirmation(formId, itemId) {
        var deleteForm = document.getElementById(formId + itemId);
        var confirmationForm = document.getElementById('confirmDeleteForm');

        // Show the confirmation dialog
        var deleteConfirmationDialog = document.getElementById('deleteConfirmationDialog');
        deleteConfirmationDialog.classList.remove('hidden');

        confirmationForm.action = deleteForm.action;
    }

    function hideDeleteConfirmation() {
        // Hide the confirmation dialog
        var deleteConfirmationDialog = document.getElementById('deleteConfirmationDialog');
        deleteConfirmationDialog.classList.add('hidden');
    }
</script>

</html>
<?php /**PATH C:\Users\Nejc Robič\Documents\Projects\Home\TenisTolmin\resources\views\components\layout.blade.php ENDPATH**/ ?>