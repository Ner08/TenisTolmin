<div
    class="mb-4 grid-flow-col items-center border-0 border-b-2 border-gray-200 text-center text-lg font-bold uppercase hidden md:grid">
    <?php $__currentLoopData = $roundTitles[$lastRound]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $title): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="w-full md:w-auto md:flex-grow-0 md:w-<?php echo e($colWidth); ?>"><?php echo e($title); ?>

        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<div class="<?php echo \Illuminate\Support\Arr::toCssClasses([
    'grid',
    'grid-flow-col',
    'grid-cols-' . $lastRound,
    'items-center',
    'pt-4',
]); ?>">
    <?php $__currentLoopData = $bracket->matchUps->sortBy('round')->groupBy('round'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $match): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="<?php echo \Illuminate\Support\Arr::toCssClasses([
            'mx-2',
            'h-1/' . 2 ** ($key + 1) => $key != 1,
            'grid',
            'grid-flow-row',
            'grid-rows-' . ($lastRound - ($key - 1)),
        ]); ?>">
            <?php $__currentLoopData = $bracket->matchUps->where('round', $key); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $match): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $team1 = App\Models\Team::where('id', $match->team1_id)->first();
                    $t1p1 = $team1->player1;
                    $t1p2 = $team1->player2;
                    $team2 = App\Models\Team::where('id', $match->team2_id)->first();
                    $t2p1 = $team2->player1;
                    $t2p2 = $team2->player2;

                    $t1_name = isset($t1p2) ? $t1p1->p_name . ' | ' . $t1p2->p_name : $t1p1->p_name;
                    $t2_name = isset($t2p2) ? $t2p1->p_name . ' | ' . $t2p2->p_name : $t2p1->p_name;

                    $t1_ranking = ($t1p1->ranking() ?? '') . (isset($t1p2) ? '-' . $t1p2->ranking() : '');
                    $t2_ranking = ($t2p1->ranking() ?? '') . (isset($t2p2) ? '-' . $t2p2->ranking() : '');

                    $winner = $match->winner() ?? null;

                    $t1_sets_won = $match->t1SetsWon();
                    $t2_sets_won = $match->t2SetsWon();
                ?>
                <div class="mb-4 rounded-md bg-gray-200 pt-2 text-gray-900">
                    <div class="flex justify-between items-center px-4">
                        <?php if($match->t1_tag): ?>
                            <div class="bg-gray-900 text-white px-2 py-1 font-semibold text-sm rounded-md mr-4">
                                <?php echo e($match->t1_tag); ?></div>
                        <?php endif; ?>
                        <?php if(isset($t1_name)): ?>
                            <?php if(!isset($match->t1_tag) && $team1->is_fake): ?>
                                <div>
                                    <p class="font-semibold text-sm"><?php echo e($t1_name); ?></p>
                                </div>
                            <?php elseif(!$team1->is_fake): ?>
                                <div>
                                    <p class="font-semibold text-sm"><?php echo e($t1_name); ?> <span
                                            class="text-blue-500">(<?php echo e($t1_ranking); ?>)</span></p>
                                </div>
                            <?php endif; ?>
                        <?php endif; ?>
                        <?php if(isset($t1_sets_won)): ?>
                            <div class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                                'text-white' => isset($winner),
                                'px-3',
                                'py-1',
                                'ml-2',
                                'rounded-full',
                                'bg-green-600' => isset($winner) && $winner,
                                'bg-red-600' => isset($winner) && !$winner,
                            ]); ?>" class=" ">
                                <p class="text-right"><?php echo e($t1_sets_won); ?></p>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="flex justify-between items-center my-2 px-4 ">
                        <?php if($match->t2_tag): ?>
                            <div class="bg-gray-900 text-white px-2 py-1 font-semibold text-sm rounded-md mr-4">
                                <?php echo e($match->t2_tag); ?></div>
                        <?php endif; ?>
                        <?php if(isset($t2_name)): ?>
                            <?php if(!isset($match->t2_tag) && $team2->is_fake): ?>
                                <div>
                                    <p class="font-semibold text-sm"><?php echo e($t2_name); ?></p>
                                </div>
                            <?php elseif(isset($match->t2_tag) && $team2->is_fake): ?>

                            <?php elseif(!$team2->is_fake): ?>
                                <div>
                                    <p class="font-semibold text-sm"><?php echo e($t2_name); ?> <span
                                            class="text-blue-500">(<?php echo e($t2_ranking); ?>)</span></p>
                                </div>
                            <?php endif; ?>
                        <?php endif; ?>
                        <?php if(isset($t2_sets_won)): ?>
                            <div class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                                'text-white' => isset($winner),
                                'px-3',
                                'py-1',
                                'ml-2',
                                'rounded-full',
                                'bg-green-600' => isset($winner) && !$winner,
                                'bg-red-600' => isset($winner) && $winner,
                            ]); ?>" class=" ">
                                <p class="text-right"><?php echo e($t2_sets_won); ?></p>
                            </div>
                        <?php endif; ?>
                    </div>
                    <?php if(isset($match->exception)): ?>
                        <div class="text-center bg-gray-600 text-gray-200 rounded-b-md font-semibold items-center pb-1">
                            <?php echo e($match->exception); ?></div>
                    <?php elseif(isset($match->endResult)): ?>
                        <div class="text-center bg-gray-600 text-gray-200 rounded-b-md font-semibold items-center pb-1">
                            <?php echo e($match->endResult); ?></div>
                    <?php endif; ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php if(isset($bracket->points_description)): ?>
    <div class="m-3 mr-8 pb-4 flex justify-end">
        <div class="bg-gray-100 rounded-lg p-4 shadow-md">
            <p class="text-gray-700 leading-relaxed"><?php echo e($bracket->points_description); ?></p>
        </div>
    </div>
<?php endif; ?>
<?php /**PATH C:\Users\Nejc Robič\Documents\Projects\Home\TenisTolmin\resources\views\partials\_admin_league.blade.php ENDPATH**/ ?>