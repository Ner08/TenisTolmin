<?php
    $dateFromFormated = date('d.m.Y', strtotime($event['fromDate']));
    $timeFromFormated = date('h:i:s', strtotime($event['fromDate']));

    if (isset($event['toDate'])) {
        $dateToFormated = date('d.m.Y', strtotime($event['toDate']));
        $timeToFormated = date('h:i:s', strtotime($event['toDate']));
    }
?>


<section class="m-3">
    <div class="container mx-auto">
        <div class="bg-gray-900 rounded-lg shadow-md overflow-hidden text-white">
            <div class="p-6">
                <h2 class="text-3xl font-semibold mb-4"><?php echo e($event['e_title']); ?></h2>
                <p class="text-gray-300 mb-4"><?php echo e($event['e_description']); ?></p>
                <div class="grid grid-cols-2 md:grid-cols-4 gap-0 mr-2">
                    <div class="p-2">
                        <div>
                            <div class="flex items-center mb-1">
                                <p class="text-lg font-bold text-gray-200 inline-block">Začetek: </p>
                            </div>
                            <div class="flex items-center mb-1">
                                <img src="<?php echo e(asset('images/calandar.svg')); ?>" alt="Calendar Icon"
                                    class="w-6 h-6 text-gray-300 mr-2 inline-block" />
                                <p class="text-lg font-semibold text-gray-200 inline-block"><?php echo e($dateFromFormated); ?></p>
                            </div>
                            <div class="flex items-center">
                                <img src="<?php echo e(asset('images/clock.svg')); ?>" alt="Clock Icon"
                                    class="w-6 h-6 text-gray-300 mr-2" />
                                <p class="text-lg font-semibold text-gray-200"><?php echo e($timeFromFormated); ?></p>
                            </div>
                        </div>
                    </div>
                    <div class="p-2">
                        <div>
                            <div class="flex items-center mb-1">
                                <p class="text-lg font-bold text-gray-200 inline-block">Konec: </p>
                            </div>
                            <div class="flex items-center mb-1">
                                <img src="<?php echo e(asset('images/calandar.svg')); ?>" alt="Calendar Icon"
                                    class="w-6 h-6 text-gray-300 mr-2 inline-block" />
                                <p class="text-lg font-semibold text-gray-200 inline-block"><?php echo e($dateToFormated); ?></p>
                            </div>
                            <div class="flex items-center">
                                <img src="<?php echo e(asset('images/clock.svg')); ?>" alt="Clock Icon"
                                    class="w-6 h-6 text-gray-300 mr-2" />
                                <p class="text-lg font-semibold text-gray-200"><?php echo e($timeToFormated); ?></p>
                            </div>
                        </div>
                    </div>
                </div>



                <div class="flex items-center mt-4">
                    <img src="<?php echo e(asset('images/location.svg')); ?>" alt="Location Icon"
                        class="w-6 h-6 text-gray-300 mr-3" />
                    <div>
                        <p class="text-lg font-semibold text-gray-200"><?php echo e($event['location']); ?></p>
                        <p class="text-sm text-gray-400">Lokacija</p>
                    </div>
                </div>
            </div>
        </div>
        <?php echo $__env->make('partials._comments', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</section>
<?php /**PATH C:\Users\Nejc Robič\Documents\Projects\Home\TenisTolmin\resources\views\partials\_event.blade.php ENDPATH**/ ?>