<section class="bg-gray-100">
    <div class="container mx-auto px-4 py-8 flex flex-wrap items-center">
        <div class="w-full">
            <h1 class="text-3xl font-bold mb-4">Pozdravljeni!</h1>
            <p class="text-lg text-gray-700 mb-4">
               Teniški klub Tolmin je športno društvo, ki skrbi za teniško kulturo v našem idiličnem  mestu.  Ustanovljeno je bilo leta 1981, neformalni začetki igranja tenisa pa segajo še dlje nazaj.
            </p>
            <p class="text-lg text-gray-700">
                Društvo ima preko 80 članov vseh starosti, ki jih druži skupna strast do tenisa.  Odprto je za vse, pod enakimi pogoji in ob spoštovanju skupnih pravil.
            </p>
        </div>
    </div>
</section>
<?php /**PATH C:\Users\Nejc Robič\Documents\Projects\Home\TenisTolmin\resources\views/partials/_welcome.blade.php ENDPATH**/ ?>