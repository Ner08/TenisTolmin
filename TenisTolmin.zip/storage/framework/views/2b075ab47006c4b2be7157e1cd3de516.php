<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => ['message' => $message ?? null,'flash' => $flash ?? null,'model' => $model ?? null]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['message' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($message ?? null),'flash' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($flash ?? null),'model' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($model ?? null)]); ?>
    <!-- Include Delete Confirmation Component -->
    <?php if (isset($component)) { $__componentOriginal9502acf056f720678e71cee27afcafd8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9502acf056f720678e71cee27afcafd8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.delete-confirmation','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('delete-confirmation'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9502acf056f720678e71cee27afcafd8)): ?>
<?php $attributes = $__attributesOriginal9502acf056f720678e71cee27afcafd8; ?>
<?php unset($__attributesOriginal9502acf056f720678e71cee27afcafd8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9502acf056f720678e71cee27afcafd8)): ?>
<?php $component = $__componentOriginal9502acf056f720678e71cee27afcafd8; ?>
<?php unset($__componentOriginal9502acf056f720678e71cee27afcafd8); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalf7d3acdbbf96ccd06bb5f5c4e34c0ca7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf7d3acdbbf96ccd06bb5f5c4e34c0ca7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-title-simple','data' => ['title' => 'Liga / Turnir • ' . $bracket->league->name]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-title-simple'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Liga / Turnir • ' . $bracket->league->name)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf7d3acdbbf96ccd06bb5f5c4e34c0ca7)): ?>
<?php $attributes = $__attributesOriginalf7d3acdbbf96ccd06bb5f5c4e34c0ca7; ?>
<?php unset($__attributesOriginalf7d3acdbbf96ccd06bb5f5c4e34c0ca7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf7d3acdbbf96ccd06bb5f5c4e34c0ca7)): ?>
<?php $component = $__componentOriginalf7d3acdbbf96ccd06bb5f5c4e34c0ca7; ?>
<?php unset($__componentOriginalf7d3acdbbf96ccd06bb5f5c4e34c0ca7); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginala29c4b6de1220dbc50317dc759b47929 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala29c4b6de1220dbc50317dc759b47929 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.title','data' => ['title' => 'Skupina • ' . $bracket->name]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Skupina • ' . $bracket->name)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala29c4b6de1220dbc50317dc759b47929)): ?>
<?php $attributes = $__attributesOriginala29c4b6de1220dbc50317dc759b47929; ?>
<?php unset($__attributesOriginala29c4b6de1220dbc50317dc759b47929); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala29c4b6de1220dbc50317dc759b47929)): ?>
<?php $component = $__componentOriginala29c4b6de1220dbc50317dc759b47929; ?>
<?php unset($__componentOriginala29c4b6de1220dbc50317dc759b47929); ?>
<?php endif; ?>

    <div class="container mx-auto mt-4 mb-8">
        <div class="bg-zinc-900 text-white py-2 px-4 rounded-t-lg">
            <h2 class="text-xl font-bold">Uredi skupino</h2>
        </div>

        <form action="<?php echo e(route('leagues.bracket_edit', ['bracket' => $bracket->id])); ?>" method="POST"
            class="mb-5 bg-gray-100 rounded-lg p-6">
            <?php echo method_field('PUT'); ?>
            <?php echo csrf_field(); ?>
            <div class="mb-4">
                <input type="hidden" name="league_id" value="<?php echo e($bracket->league->id); ?>">
                <label for="name" class="block text-gray-700 font-semibold">Ime skupine:</label>
                <input type="text" name="name" id="name" placeholder="Vnesite ime skupine"
                    class="form-input rounded-lg w-full focus:outline-none focus:border-blue-500 border-gray-300 py-3 px-4"
                    value="<?php echo e($bracket->name); ?>" required>
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="mb-6">
                <label for="is_group_stage">Skupinski del</label>
                <input type="checkbox" name="is_group_stage" id="is_group_stage" class="ml-2"
                    value="1" <?php if($bracket->is_group_stage == 1): ?> checked <?php endif; ?>>
                <?php $__errorArgs = ['is_group_stage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="mb-4" id="pointsDescriptionContainer">
                <label for="points_description" class="block text-gray-700 font-semibold">Opis števila
                    točk:</label>
                <input type="text" name="points_description" id="points_description"
                    placeholder="Vnesite opis števila točk pridobljenih glede na doseženo mesto"
                    class="form-input rounded-lg w-full focus:outline-none focus:border-blue-500 border-gray-300 py-3 px-4"
                    value="<?php echo e($bracket->points_description); ?>" <?php if($bracket->is_group_stage == 1): ?> disabled <?php endif; ?>>
                <?php $__errorArgs = ['points_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="mb-4" id="tagContainer">
                <label for="tag" class="block text-gray-700 font-semibold">Oznaka skupine:</label>
                <input type="text" name="tag" id="tag" placeholder="Vpišite oznako skupine (Primer: A)"
                    class="form-input rounded-lg w-full focus:outline-none focus:border-blue-500 border-gray-300 py-3 px-4"
                    value="<?php echo e($bracket->tag); ?>" <?php if($bracket->is_group_stage == 0): ?> disabled <?php endif; ?>>
                <?php $__errorArgs = ['tag'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="mt-4 mb-4" id="teamsContainer">
                <label for="teams"
                    class="block bg-gray-600 text-white font-semibold py-2 mb-2 px-4 rounded">Ekipe:</label>
                <div id="teamsInputs">
                    <?php
                        $nonFakeIndex = 0;
                    ?>
                    <?php $__currentLoopData = $bracket->teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($team->is_fake): ?>
                            <?php continue; ?>
                        <?php endif; ?>
                        <div class="mb-2 team">
                            <label for="teams"
                                class="block bg-gray-400 text-white font-semibold text-sm py-1 mb-2 px-4 rounded">Ekipa
                                <?php echo e($nonFakeIndex + 1); ?></label>
                            <div class="mb-2 teamInput">
                                <div class="border-b-2 border-gray-300 pb-4">
                                    <input type="hidden" name="teams[<?php echo e($nonFakeIndex); ?>][id]"
                                        value="<?php echo e($team->id); ?>">
                                    <label for="teamName" class="block text-gray-700 font-semibold">Ime ekipe:</label>
                                    <input type="text" name="teams[<?php echo e($nonFakeIndex); ?>][name]"
                                        placeholder="Ime ekipe (neobvezno)"
                                        class="form-input rounded-lg w-full focus:outline-none focus:border-blue-500 border-gray-300 py-3 px-4 mt-3"
                                        value="<?php echo e($team->name); ?>">
                                    <?php $__currentLoopData = $team->players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $playerIndex => $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($playerIndex == 0): ?>
                                            <label for="firstPlayer" class="block text-gray-700 font-semibold mt-2">Prvi
                                                igralec:</label>
                                        <?php elseif($playerIndex == 1): ?>
                                            <label for="secondPlayer"
                                                class="block text-gray-700 font-semibold mt-2">Drugi
                                                igralec:</label>
                                        <?php endif; ?>
                                        <select name="teams[<?php echo e($nonFakeIndex); ?>][player_ids][]"
                                            class="form-select rounded-lg w-full focus:outline-none focus:border-blue-500 border-gray-300 py-3 px-4 mt-3"
                                            required>
                                            <option value="">Izberi prvega igralca</option>
                                            <!-- Use foreach to generate dropdown options for players -->
                                            <?php $__currentLoopData = $playersSelect; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $optionPlayer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($optionPlayer->id); ?>"
                                                    <?php if($optionPlayer->id == $player->id): ?> selected <?php endif; ?>>
                                                    <?php echo e($optionPlayer->p_name); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ["teams.${nonFakeIndex}.player_ids.${playerIndex}"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <button type="button" class="removeTeamBtn ml-2">Odstrani</a>
                                </div>
                            </div>
                            <?php
                                $nonFakeIndex++;
                            ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            <button type="button" id="addTeamBtn"
                class="bg-zinc-900 text-white px-4 py-2 rounded-lg hover:bg-zinc-800 focus:outline-none mt-1">Dodaj
                ekipo</button>
            <div class="mt-3">
                <button type="submit"
                    class="bg-zinc-500 text-white px-8 py-3 rounded-lg hover:bg-zinc-600 focus:outline-none transition duration-300 mt-2">Shrani
                </button>
            </div>
    </div>


    </div>
    </form>
    </div>

    <?php if (isset($component)) { $__componentOriginala29c4b6de1220dbc50317dc759b47929 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala29c4b6de1220dbc50317dc759b47929 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.title','data' => ['title' => 'Igre v skupini']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Igre v skupini']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala29c4b6de1220dbc50317dc759b47929)): ?>
<?php $attributes = $__attributesOriginala29c4b6de1220dbc50317dc759b47929; ?>
<?php unset($__attributesOriginala29c4b6de1220dbc50317dc759b47929); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala29c4b6de1220dbc50317dc759b47929)): ?>
<?php $component = $__componentOriginala29c4b6de1220dbc50317dc759b47929; ?>
<?php unset($__componentOriginala29c4b6de1220dbc50317dc759b47929); ?>
<?php endif; ?>
    <?php
        $lastRound = $bracket->matchUps->max('round') ?? 10;
        $roundTitles = [
            1 => ['Finale'],
            2 => ['Polfinale', 'Finale'],
            3 => ['Četrtfinale', 'Polfinale', 'Finale'],
            4 => ['Osminafinala', 'Četrtfinale', 'Polfinale', 'Finale'],
            5 => ['1.Krog', 'Osminafinala', 'Četrtfinale', 'Polfinale', 'Finale'],
            6 => ['1.Krog', '2.Krog', 'Osminafinala', 'Četrtfinale', 'Polfinale', 'Finale'],
            7 => ['1.Krog', '2.Krog', '3.Krog', 'Osminafinala', 'Četrtfinale', 'Polfinale', 'Finale'],
            8 => ['1.Krog', '2.Krog', '3.Krog', '4.Krog', 'Osminafinala', 'Četrtfinale', 'Polfinale', 'Finale'],
            9 => [
                '1.Krog',
                '2.Krog',
                '3.Krog',
                '4.Krog',
                '5.Krog',
                'Osminafinala',
                'Četrtfinale',
                'Polfinale',
                'Finale',
            ],
            10 => ['Tekme še niso določene.'],
        ];

        // Calculate the width of each column
        $colWidth = 12 / $lastRound; // Divide 12 (the number of columns in Bootstrap grid system) by the total number of rounds
    ?>
    <div class="mt-4">
        <?php if($bracket->is_group_stage): ?>
            <?php echo $__env->make('partials._admin_league_group_stage', ['bracket' => $bracket], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php else: ?>
            <?php echo $__env->make('partials._admin_league', ['bracket' => $bracket], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
    </div>
    <div class="bg-gray-200">
        <div class="container mx-auto pt-4 px-4 ">
            <div class="bg-zinc-900 text-white py-2 px-4 rounded-t-lg">
                <h2 class="text-xl font-bold">Dodaj igro</h2>
            </div>
            <form action="<?php echo e(route('leagues.matchup_store')); ?>" method="POST" class="mb-5 bg-gray-100 rounded-lg p-6">
                <?php echo csrf_field(); ?>
                <!-- Team 1 Inputs -->
                <div class="mb-4">
                    <input type="hidden" name="bracket_id" value="<?php echo e($bracket->id); ?>">
                    <label for="teams" class="block text-gray-700 font-semibold mb-2">Igralec / Ekipa 1:</label>
                    <div>
                        <!-- Team 1 ID -->
                        <select name="team1_id"
                            class="form-select rounded-lg w-full focus:outline-none focus:border-blue-500 border-gray-300 py-3 px-4 mt-3">
                            <option required>Izberite ekipo</option>
                            <!-- Use foreach to generate dropdown options for players -->
                            <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($team->id); ?>">
                                    <?php echo e($team->playerNames()); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['team1_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <?php if(!$bracket->is_group_stage): ?>
                        <label for="t1_tag"
                            class="block bg-gray-400 text-white font-semibold text-sm py-1 mb-0 px-4 mt-3 rounded-b-none rounded-lg">Oznaka</label>
                        <input type="text" name="t1_tag"
                            class="form-input w-full focus:outline-none border-gray-300 py-2 px-4 mt-0 rounded-t-none rounded-lg"
                            placeholder="Oznaka igralca / ekipe" value="<?php echo e(old('t1_tag')); ?>"/>
                        <?php $__errorArgs = ['t1_tag'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <?php endif; ?>
                </div>

                <!-- Team 2 Inputs -->
                <div class="mb-4">
                    <label for="teams" class="block text-gray-700 font-semibold mb-2">Igralec / Ekipa 2:</label>
                    <div>
                        <!-- Team 2 ID -->
                        <select name="team2_id"
                            class="form-select rounded-lg w-full focus:outline-none focus:border-blue-500 border-gray-300 py-3 px-4 mt-3">
                            <option required>Izberite ekipo</option>
                            <!-- Use foreach to generate dropdown options for players -->
                            <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($team->id); ?>">
                                    <?php echo e($team->playerNames()); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['team2_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            
                            <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <?php if(!$bracket->is_group_stage): ?>
                        <label for="t2_tag"
                            class="block bg-gray-400 text-white font-semibold text-sm py-1 mb-0 px-4 mt-3 rounded-b-none rounded-lg">Oznaka</label>
                        <input type="text" name="t2_tag"
                            class="form-input w-full focus:outline-none border-gray-300 py-2 px-4 mt-0 rounded-t-none rounded-lg"
                            placeholder="Oznaka igralca / ekipe" value="<?php echo e(old('t2_tag')); ?>" />
                        <?php $__errorArgs = ['t2_tag'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <?php endif; ?>
                </div>

                <label for="t1_first_set" class="block text-gray-700 font-semibold mb-2">1. Set:</label>
                <!--Score input -->
                <div class="mb-4 grid grid-cols-2 gap-4">
                    <div>
                        <input type="number" name="t1_first_set"
                            class="form-input rounded-lg w-full focus:outline-none focus:border-blue-500 border-gray-300 py-3 px-4 mt-3"
                            placeholder="Ekipa/igralec 1 prvi set" value="<?php echo e(old('t1_first_set')); ?>"/>
                    </div>
                    <div>
                        <input type="number" name="t2_first_set"
                            class="form-input rounded-lg w-full focus:outline-none focus:border-blue-500 border-gray-300 py-3 px-4 mt-3"
                            placeholder="Ekipa/igralec 2 prvi set" value="<?php echo e(old('t2_first_set')); ?>"/>
                    </div>
                </div>
                <?php $__errorArgs = ['t1_first_set'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <?php $__errorArgs = ['t2_first_set'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <label for="t1_first_set" class="block text-gray-700 font-semibold mb-2">2. Set:</label>
                <div class="mb-4 grid grid-cols-2 gap-4">
                    <div>
                        <input type="number" name="t1_second_set"
                            class="form-input rounded-lg w-full focus:outline-none focus:border-blue-500 border-gray-300 py-3 px-4 mt-3"
                            placeholder="Ekipa/igralec 1 drugi set" value="<?php echo e(old('t1_second_set')); ?>"/>
                    </div>
                    <div>
                        <input type="number" name="t2_second_set"
                            class="form-input rounded-lg w-full focus:outline-none focus:border-blue-500 border-gray-300 py-3 px-4 mt-3"
                            placeholder="Ekipa/igralec 2 drugi set" value="<?php echo e(old('t2_second_set')); ?>"/>
                    </div>
                </div>
                <?php $__errorArgs = ['t1_second_set'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <?php $__errorArgs = ['t2_second_set'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <label for="t1_first_set" class="block text-gray-700 font-semibold mb-2">3. Set:</label>
                <div class="mb-4 grid grid-cols-2 gap-4">
                    <div>
                        <input type="number" name="t1_third_set" min="0"
                            class="form-input rounded-lg w-full focus:outline-none focus:border-blue-500 border-gray-300 py-3 px-4 mt-3"
                            placeholder="Ekipa/igralec 1 tretji set" value="<?php echo e(old('t1_third_set')); ?>"/>
                    </div>
                    <div>
                        <input type="number" name="t2_third_set" min="0"
                            class="form-input rounded-lg w-full focus:outline-none focus:border-blue-500 border-gray-300 py-3 px-4 mt-3"
                            placeholder="Ekipa/igralec 2 tretji set" value="<?php echo e(old('t2_third_set')); ?>"/>
                    </div>
                </div>
                <?php $__errorArgs = ['t1_third_set'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <?php $__errorArgs = ['t2_third_set'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="mb-4">
                    <label for="exception" class="block text-gray-700 font-semibold mb-2">Besedilo po meri</label>
                    <input type="text" name="exception"
                        class="form-input rounded-lg w-full focus:outline-none focus:border-blue-500 border-gray-300 py-3 px-4 mt-3"
                        placeholder="Vnesi besedilo (Prepiše skupni rezultat) Primer: Brez boja " value="<?php echo e(old('exception')); ?>"/>
                </div>
                <?php $__errorArgs = ['exception'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="mb-4 grid grid-cols-2 gap-4">
                    <div>
                        <label for="round" class="block text-gray-700 font-semibold mb-2">Runda:</label>
                        <input type="number" name="round" min="1" max="9"
                            class="form-input rounded-lg w-full focus:outline-none focus:border-blue-500 border-gray-300 py-3 px-4 mt-3"
                            placeholder="Vnesi rundo (v katerem krogu bo igra potekala)" value="<?php echo e(old('round')); ?>"/>
                    </div>
                </div>
                <?php $__errorArgs = ['round'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <!-- Submit Button -->
                <button type="submit"
                    class="bg-zinc-500 text-white px-8 py-3 rounded-lg hover:bg-zinc-600 focus:outline-none transition duration-300 mt-2">Dodaj
                    igro</button>
            </form>

            <!-- Display list of brackets with edit and delete buttons -->
            <ul class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                <?php if($matchups->isEmpty()): ?>
                    <h2 class="p-4 text-gray-900">Nismo našli nobene igre.</h2>
                <?php else: ?>
                    <?php $__currentLoopData = $matchups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $match): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $team1 = App\Models\Team::where('id', $match->team1_id)->first();
                            $t1p1 = $team1->player1;
                            $t1p2 = $team1->player2;
                            $team2 = App\Models\Team::where('id', $match->team2_id)->first();
                            $t2p1 = $team2->player1;
                            $t2p2 = $team2->player2;

                            $t1_name = isset($t1p2) ? $t1p1->p_name . ' | ' . $t1p2->p_name : $t1p1->p_name;
                            $t2_name = isset($t2p2) ? $t2p1->p_name . ' | ' . $t2p2->p_name : $t2p1->p_name;

                            $t1_ranking = ($t1p1->ranking() ?? '') . (isset($t1p2) ? '-' . $t1p2->ranking() : '');
                            $t2_ranking = ($t2p1->ranking() ?? '') . (isset($t2p2) ? '-' . $t2p2->ranking() : '');

                            $winner = $match->winner() ?? null;

                            $t1_sets_won = $match->t1SetsWon();
                            $t2_sets_won = $match->t2SetsWon();
                        ?>
                        <li class="bg-white rounded-lg shadow-md p-6">
                            <div class="flex items-center justify-between mb-4">
                                <div>
                                    <h3 class="text-md font-semibold text-gray-900 mb-2"><?php echo e($match->round); ?>.
                                        Runda</h3>
                                    <h3 class="text-xl font-semibold text-gray-900 mb-2"><?php echo e($t1_name); ?> -
                                        <?php echo e($t2_name); ?></h3>
                                    <?php if(isset($match->exception)): ?>
                                        <div class="inline-block mt-2">
                                            <h4 class="text-xl font-bold text-gray-500 mx-auto">
                                                <span
                                                    class="bg-gray-900 text-gray-100 px-2 py-1 rounded"><?php echo e($match->exception); ?></span>
                                            </h4>
                                        </div>
                                    <?php elseif(isset($match->endResult)): ?>
                                        <div class="inline-block mt-2">
                                            <h4 class="text-xl font-bold text-gray-500 mx-auto">
                                                <span
                                                    class="bg-gray-900 text-gray-100 px-2 py-1 rounded"><?php echo e($match->endResult); ?></span>
                                            </h4>
                                        </div>
                                    <?php endif; ?>
                                </div>

                            </div>
                            <p>
                                <span class="text-sm font-semibold text-gray-500">Ustvarjeno:</span>
                                <span
                                    class="text-sm text-gray-500"><?php echo e(\Carbon\Carbon::parse($match->created_at)->format('d.m.Y')); ?></span>
                            </p>
                            <div class="flex items-center">
                                <a href="<?php echo e(route('matchup_edit', ['bracket' => $bracket->id, 'customMatchup' => $match->id])); ?>"
                                    class="text-blue-500 hover:underline mr-4">Uredi</a>
                                <form id="deleteForm<?php echo e($match->id); ?>"
                                    action="<?php echo e(route('league.matchup_destroy', ['matchup' => $match->id])); ?>"
                                    method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="button"
                                        onclick="showDeleteConfirmation('deleteForm', <?php echo e($match->id); ?>)"
                                        class="text-red-500 hover:underline">Izbriši</button>
                                </form>
                            </div>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </ul>
            <div class="p-4"><?php echo e($matchups->links()); ?></div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>

<style>
    .removeTeamBtn {
        background-color: transparent;
        border: none;
        margin-top: 10px;
        color: #EF4444;
        cursor: pointer;
        font-size: 15px;
        outline: none;
        transition: color 0.3s ease;
    }

    .removeTeamBtn:hover {
        color: #DC2626;
    }

    input:disabled {
        background-color: #e2e5ea;
        /* Custom color */
    }

    .team {
        border: 0;
        margin: 0;
        padding: 0;
    }
</style>

<script>
    let teamIndex = <?php echo e($numOfTeams); ?>;
    // Add team input field
    function addTeamInput() {
        const teamsContainer = document.getElementById('teamsInputs');
        // Count the number of valid team inputs
        const newInput = document.createElement('div');
        newInput.classList.add('mb-2', 'team');
        newInput.innerHTML = `
            <div class="border-b-2 border-gray-300 pb-4">
                <label for="teams" class="block bg-gray-400 text-white font-semibold text-sm py-1 mb-2 px-4 rounded">Ekipa ${teamIndex + 1}</label>
                <div class="teamInput">
                    <label for="teamName" class="block text-gray-700 font-semibold">Ime ekipe:</label>
                    <input type="text" name="teams[${teamIndex}][name]" placeholder="Ime ekipe (neobvezno)"
                        class="form-input rounded-lg w-full focus:outline-none focus:border-blue-500 border-gray-300 py-3 px-4 mt-3">
                    <label for="firstPlayer" class="block text-gray-700 font-semibold mt-3">Prvi igralec:</label>
                    <select name="teams[${teamIndex}][player_ids][]" class="form-select rounded-lg w-full focus:outline-none focus:border-blue-500 border-gray-300 py-3 px-4 mt-3" required>
                        <option value="">Izberi prvega igralca</option>
                        <!-- Use foreach to generate dropdown options for players -->
                        <?php $__currentLoopData = $playersSelect; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($player->id); ?>"><?php echo e($player->p_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['teams.${teamIndex}.player_ids.0'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <label for="secondPlayer" class="block text-gray-700 font-semibold mt-3">Drugi igralec:</label>
                    <select name="teams[${teamIndex}][player_ids][]" class="form-select rounded-lg w-full focus:outline-none focus:border-blue-500 border-gray-300 py-3 px-4 mt-1">
                        <option value="">Izberi drugega igralca (neobvezno)</option>
                        <!-- Use foreach to generate dropdown options for players -->
                        <?php $__currentLoopData = $playersSelect; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($player->id); ?>"><?php echo e($player->p_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['teams.${teamIndex}.player_ids.1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                        <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <button type="button" class="removeTeamBtn ml-2">Odstrani</button>
                </div>
            </div>`;
        teamsContainer.appendChild(newInput);

        teamIndex++;

        // Add event listener to remove button
        newInput.querySelector('.removeTeamBtn').addEventListener('click', function() {
            teamsContainer.removeChild(newInput);
        });
    }

    document.getElementById('addTeamBtn').addEventListener('click', addTeamInput);

    // Ensure that the value of is_group_stage is set to "0" if the checkbox is not checked when the form is submitted
    const form = document.querySelector('form');
    form.addEventListener('submit', function() {
        const isGroupStageCheckbox = document.getElementById('is_group_stage');
        if (!isGroupStageCheckbox.checked) {
            // Create a hidden input field for is_group_stage with value "0"
            const hiddenInput = document.createElement('input');
            hiddenInput.type = 'hidden';
            hiddenInput.name = 'is_group_stage';
            hiddenInput.value = '0';
            form.appendChild(hiddenInput);
        }
    });

    // Function to enable/disable the points description input based on checkbox status
    document.getElementById('is_group_stage').addEventListener('change', function() {
        var pointsDescriptionInput = document.getElementById('points_description');
        var tagInput = document.getElementById('tag');
        pointsDescriptionInput.disabled = this.checked;
        tagInput.disabled = !this.checked;
    });

    // Remove team input field
    document.addEventListener('click', function(event) {
        if (event.target.classList.contains('removeTeamBtn')) {
            const team = event.target.closest('.team');
            team.remove();
        }
    });
</script>
<?php /**PATH C:\Users\Nejc Robič\Documents\Projects\Home\TenisTolmin\resources\views\admin\matchup_store.blade.php ENDPATH**/ ?>