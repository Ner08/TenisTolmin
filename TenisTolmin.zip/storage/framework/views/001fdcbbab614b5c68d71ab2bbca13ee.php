<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => ['scroll' => $scroll,'message' => $message ?? null,'flash' => $flash ?? null,'model' => $model ?? null]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['scroll' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($scroll),'message' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($message ?? null),'flash' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($flash ?? null),'model' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($model ?? null)]); ?>
    <!-- Include Delete Confirmation Component -->
    <?php if (isset($component)) { $__componentOriginal9502acf056f720678e71cee27afcafd8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9502acf056f720678e71cee27afcafd8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.delete-confirmation','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('delete-confirmation'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9502acf056f720678e71cee27afcafd8)): ?>
<?php $attributes = $__attributesOriginal9502acf056f720678e71cee27afcafd8; ?>
<?php unset($__attributesOriginal9502acf056f720678e71cee27afcafd8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9502acf056f720678e71cee27afcafd8)): ?>
<?php $component = $__componentOriginal9502acf056f720678e71cee27afcafd8; ?>
<?php unset($__componentOriginal9502acf056f720678e71cee27afcafd8); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginal49c06cc89aff608606497c05c8e6f499 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal49c06cc89aff608606497c05c8e6f499 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-title','data' => ['title' => 'Adminstracijska plošča']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Adminstracijska plošča']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal49c06cc89aff608606497c05c8e6f499)): ?>
<?php $attributes = $__attributesOriginal49c06cc89aff608606497c05c8e6f499; ?>
<?php unset($__attributesOriginal49c06cc89aff608606497c05c8e6f499); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal49c06cc89aff608606497c05c8e6f499)): ?>
<?php $component = $__componentOriginal49c06cc89aff608606497c05c8e6f499; ?>
<?php unset($__componentOriginal49c06cc89aff608606497c05c8e6f499); ?>
<?php endif; ?>

    

    <div id="lige">
        <?php if (isset($component)) { $__componentOriginala29c4b6de1220dbc50317dc759b47929 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala29c4b6de1220dbc50317dc759b47929 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.title','data' => ['title' => 'Lige in turnirji']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Lige in turnirji']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala29c4b6de1220dbc50317dc759b47929)): ?>
<?php $attributes = $__attributesOriginala29c4b6de1220dbc50317dc759b47929; ?>
<?php unset($__attributesOriginala29c4b6de1220dbc50317dc759b47929); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala29c4b6de1220dbc50317dc759b47929)): ?>
<?php $component = $__componentOriginala29c4b6de1220dbc50317dc759b47929; ?>
<?php unset($__componentOriginala29c4b6de1220dbc50317dc759b47929); ?>
<?php endif; ?>
    </div>
    <div class="bg-gray-200">

        <div class="bg-gray-200">
            <div class="container mx-auto pt-4 px-4 ">
                <!-- Add new legue form -->
                <div class="bg-zinc-900 text-white py-2 px-4 rounded-t-lg">
                    <h2 class="text-xl font-bold">Dodaj ligo ali turnir</h2>
                </div>
                <form action="<?php echo e(route('leagues.store')); ?>" method="POST" class="mb-5 bg-gray-100 rounded-lg p-6">
                    <?php echo csrf_field(); ?>
                    <div class="mb-4">
                        <label for="name" class="block text-gray-700 font-semibold">Ime lige ali turnirja:</label>
                        <input type="text" name="name" id="name" placeholder="Enter league name"
                            class="form-input rounded-lg w-full focus:outline-none  border-gray-300 py-3 px-4"
                            value="<?php echo e(old('name')); ?>" required>
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-4">
                        <label for="description" class="block text-gray-700 font-semibold">Opis:</label>
                        <textarea name="description" id="description" placeholder="Enter league description"
                            class="form-textarea rounded-lg w-full h-48 focus:outline-none  border-gray-300 py-3 px-4" required><?php echo e(old('description')); ?></textarea>
                        <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-4">
                        <label for="start_date" class="block text-gray-700 font-semibold">Start Date:</label>
                        <input type="date" name="start_date" id="start_date"
                            class="form-input rounded-lg w-full focus:outline-none  border-gray-300 py-3 px-4"
                            value="<?php echo e(old('start_date')); ?>" required>
                        <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-4">
                        <label for="end_date" class="block text-gray-700 font-semibold">End Date (neobvezno):</label>
                        <input type="date" name="end_date" id="end_date"
                            class="form-input rounded-lg w-full focus:outline-none border-gray-300 py-3 px-4"
                            value="<?php echo e(old('end_date')); ?>">
                        <?php $__errorArgs = ['end_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <button type="submit"
                        class="bg-zinc-500 text-white px-8 py-3 rounded-lg hover:bg-zinc-600 focus:outline-none transition duration-300">Dodaj
                    </button>
                </form>


                <form action="" method="GET" class="flex flex-col items-start">
                    <div class="flex mb-4" id="news">
                        <input type="text" name="search_leagues" id="search_news" placeholder="Iskanje"
                            class="form-input rounded-lg py-3 px-4 w-full h-12 sm:w-64 mb-2 sm:mb-0 focus:outline-none "
                            value="<?php echo e(isset($search_leagues) ? $search_leagues : ''); ?>">
                        <button type="submit"
                            class="bg-zinc-600 text-white px-6 h-12 ml-2 rounded-lg hover:bg-zinc-700 focus:outline-none focus:bg-zinc-7s00">Iskanje
                        </button>
                    </div>
                </form>
                <!-- Display list of leagues with edit and delete buttons -->
                <ul class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                    <?php if($leagues->isEmpty()): ?>
                        <h2 class="p-4 text-gray-900">Nismo našli nobene lige.</h2>
                    <?php else: ?>
                        <?php $__currentLoopData = $leagues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="bg-white rounded-lg shadow-md p-6 mb-6">
                                <!-- League Details -->
                                <div class="flex items-center justify-between mb-4 overflow-hidden">
                                    <div>
                                        <h3 class="text-xl font-bold mb-2"><?php echo e($item->name); ?></h3>
                                        <p class="text-gray-700 line-clamp-3"><?php echo e($item->description); ?></p>
                                    </div>
                                </div>
                                <div>
                                    <p class="text-gray-500 mt-4">
                                        <span class="text-sm font-semibold">Od:</span>
                                        <span
                                            class="text-sm"><?php echo e(\Carbon\Carbon::parse($item->start_date)->format('d.m.Y')); ?></span>
                                        <span class="text-sm font-semibold ml-4">Do:</span>
                                        <span
                                            class="text-sm"><?php echo e(\Carbon\Carbon::parse($item->end_date)->format('d.m.Y')); ?></span>
                                    </p>
                                </div>
                                <div class="flex items-center justify-between">
                                    <p>
                                        <span class="text-sm font-semibold text-gray-500">Ustvarjeno:</span>
                                        <span
                                            class="text-sm text-gray-500"><?php echo e(\Carbon\Carbon::parse($item->created_at)->format('d.m.Y')); ?></span>
                                    </p>
                                    <div class="flex items-center">
                                        <a href="<?php echo e(route('bracket_setup', $item->id)); ?>"
                                            class="text-blue-500 hover:underline mr-4">Uredi</a>
                                        <!-- Delete Form with Confirmation Dialog -->
                                        <form id="deleteForm<?php echo e($item->id); ?>"
                                            action="<?php echo e(route('league.destroy', ['league' => $item->id])); ?>"
                                            method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="button"
                                                onclick="showDeleteConfirmation('deleteForm', <?php echo e($item->id); ?>)"
                                                class="text-red-500 hover:underline">Izbriši</button>
                                        </form>
                                    </div>
                                </div>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </ul>
                <div class="p-4"><?php echo e($leagues->links()); ?></div>
            </div>
        </div>

        <div id="igralci">
            <?php if (isset($component)) { $__componentOriginala29c4b6de1220dbc50317dc759b47929 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala29c4b6de1220dbc50317dc759b47929 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.title','data' => ['title' => 'Igralci']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Igralci']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala29c4b6de1220dbc50317dc759b47929)): ?>
<?php $attributes = $__attributesOriginala29c4b6de1220dbc50317dc759b47929; ?>
<?php unset($__attributesOriginala29c4b6de1220dbc50317dc759b47929); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala29c4b6de1220dbc50317dc759b47929)): ?>
<?php $component = $__componentOriginala29c4b6de1220dbc50317dc759b47929; ?>
<?php unset($__componentOriginala29c4b6de1220dbc50317dc759b47929); ?>
<?php endif; ?>
        </div>
        <div class="bg-gray-200">

            <!-- Players Section -->
            <div class="container mx-auto pt-4 px-4 mb-8">
                <div class="mb-4">
                    <form action="<?php echo e(route('players_store')); ?>" method="POST"
                        class="bg-gray-100 rounded-lg overflow-hidden">
                        <div class="bg-zinc-900 text-white py-2 px-4 rounded-t-lg">
                            <h2 class="text-xl font-bold">Dodaj igralca</h2>
                        </div>
                        <div class="p-4">
                            <?php echo csrf_field(); ?>
                            <div class="flex flex-col mb-2 sm:flex-row">
                                <div class="flex flex-col mr-4 mb-2 sm:mb-0">
                                    <label for="p_name" class="mb-2">Ime:</label>
                                    <input type="text" name="p_name" id="p_name"
                                        placeholder="Vnesi ime igralca"
                                        class="form-input rounded-lg py-3 px-4 w-full sm:w-64 mb-2 sm:mb-0 focus:outline-none "
                                        value="<?php echo e(old('p_name')); ?>" required>
                                    <?php $__errorArgs = ['p_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="flex flex-col mr-4 mb-2 sm:mb-0">
                                    <label for="points" class="mb-2">Točke:</label>
                                    <input type="number" name="points" id="points" value="0"
                                        min="0"
                                        class="form-input rounded-lg py-3 px-4 w-full sm:w-24 mb-2 sm:mb-0 focus:outline-none "
                                        value="<?php echo e(old('points')); ?>" required>
                                    <?php $__errorArgs = ['points'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="flex items-end pb-4 sm:mb-0">
                                    <input type="checkbox" name="is_standin" id="is_standin"
                                        class="mr-2 bg-gray-300 rounded-sm h-5 w-5" onchange="togglePointsInput()"
                                        value="1">
                                    <label for="is_standin" class="text-gray-700 font-semibold mr-4">Ni pravi
                                        igralec</label>
                                    <?php $__errorArgs = ['is_standin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="flex flex-col mr-4">
                                    <button type="submit"
                                        class="bg-zinc-600 text-white mt-8 px-3 py-3 rounded-lg hover:bg-zinc-700 focus:outline-none focus:bg-zinc-700">Dodaj</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>

                <form action="" method="GET" class="flex flex-col items-start">
                    <div class="flex mb-4" id="players">
                        <input type="text" name="search_players" id="search_players" placeholder="Iskanje"
                            class="form-input rounded-lg py-3 px-4 w-full h-12 sm:w-64 mb-2 sm:mb-0 focus:outline-none"
                            value="<?php echo e(isset($search_players) ? $search_players : ''); ?>">
                        <button type="submit"
                            class="bg-zinc-600 text-white px-6 h-12 ml-2 rounded-lg hover:bg-zinc-700 focus:outline-none focus:bg-zinc-7s00">Iskanje
                        </button>
                    </div>
                </form>

                <!-- Display list of players with edit and delete buttons -->
                <ul class="grid grid-cols-1 lg:grid-cols-2 2xl:grid-cols-3 gap-3">
                    <?php if($players->isEmpty()): ?>
                        <h2 class="p-4 text-gray-900">Nismo našli nobenega igralca.</h2>
                    <?php else: ?>
                        <?php $__currentLoopData = $players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="bg-white rounded-lg shadow-md p-3">
                                <div class="flex flex-col md:flex-row justify-between items-center">
                                    <div class="mb-2 md:mb-0">
                                        <p class="text-xl font-semibold"><?php echo e($player->p_name); ?></p>
                                        <p class="text-gray-600">Točke: <?php echo e($player->points); ?></p>
                                    </div>
                                    <div class="flex items-center">
                                        <!-- Form to add points -->
                                        <form action="<?php echo e(route('players_add_points', ['player_id' => $player->id])); ?>"
                                            method="POST" class="mr-4">
                                            <?php echo csrf_field(); ?>
                                            <input type="number" name="points" id="points" placeholder="Točke"
                                                class="form-input rounded-lg pl-2 h-8 w-16 focus:outline-none bg-gray-300"
                                                required>
                                            <button type="submit"
                                                class="bg-green-500 text-white px-2 py-1 rounded-md hover:bg-green-600 focus:outline-none focus:bg-green-600">Dodaj</button>
                                        </form>
                                        <!-- Edit and Delete buttons -->
                                        <a href="<?php echo e(route('player_edit', $player->id)); ?>"
                                            class="text-blue-500 hover:underline mr-4">Uredi</a>
                                        <form id="deletePlayersForm<?php echo e($player->id); ?>"
                                            action="<?php echo e(route('players_destroy', ['player' => $player->id])); ?>"
                                            method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="button"
                                                onclick="showDeleteConfirmation('deletePlayersForm', <?php echo e($player->id); ?>)"
                                                class="text-red-500 hover:underline">Izbriši</button>
                                        </form>
                                    </div>
                                </div>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php endif; ?>
                </ul>
                <div class="p-2"><?php echo e($players->links('pagination::tailwind')); ?></div>
            </div>

            <!-- News Section -->
            <div id="novice">
                <?php if (isset($component)) { $__componentOriginala29c4b6de1220dbc50317dc759b47929 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala29c4b6de1220dbc50317dc759b47929 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.title','data' => ['title' => 'Novice']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Novice']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala29c4b6de1220dbc50317dc759b47929)): ?>
<?php $attributes = $__attributesOriginala29c4b6de1220dbc50317dc759b47929; ?>
<?php unset($__attributesOriginala29c4b6de1220dbc50317dc759b47929); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala29c4b6de1220dbc50317dc759b47929)): ?>
<?php $component = $__componentOriginala29c4b6de1220dbc50317dc759b47929; ?>
<?php unset($__componentOriginala29c4b6de1220dbc50317dc759b47929); ?>
<?php endif; ?>
            </div>

            <div class="container mx-auto mt-3 mb-8 px-4">
                <!-- Add new news form -->
                <div class="bg-zinc-900 text-white py-2 px-4 rounded-t-lg">
                    <h2 class="text-xl font-bold">Dodaj novice</h2>
                </div>
                <form action="<?php echo e(route('news_store')); ?>" method="POST" class="mb-5 bg-gray-100 rounded-lg p-6"
                    enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="mb-4">
                        <label for="title" class="block text-gray-700 font-semibold">Naslov:</label>
                        <input type="text" name="title" id="title" placeholder="Vnesite naslov"
                            class="form-input rounded-lg w-full focus:outline-none  border-gray-300 py-3 px-4"
                            value="<?php echo e(old('title')); ?>" required>
                        <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-4">
                        <label for="content" class="block text-gray-700 font-semibold">Vsebina:</label>
                        <textarea name="content" id="content" placeholder="Vnesite vsebino"
                            class="form-textarea rounded-lg w-full h-48 focus:outline-none  border-gray-300 py-3 px-4" required><?php echo e(old('content')); ?></textarea>
                        <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-4">
                        <label for="file" class="block text-gray-700 font-semibold">Datoteka:</label>
                        <input type="file" name="image" id="image"
                            class="form-input rounded-lg w-full focus:outline-none  border-gray-300 py-3"
                            value="<?php echo e(old('image')); ?>" required>
                        <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <button type="submit"
                        class="bg-zinc-500 text-white px-8 py-3 rounded-lg hover:bg-zinc-600 focus:outline-none transition duration-300">Dodaj
                    </button>
                </form>


                <form action="" method="GET" class="flex flex-col items-start">
                    <div class="flex mb-4" id="news">
                        <input type="text" name="search_news" id="search_news" placeholder="Iskanje"
                            class="form-input rounded-lg py-3 px-4 w-full h-12 sm:w-64 mb-2 sm:mb-0 focus:outline-none "
                            value="<?php echo e(isset($search_news) ? $search_news : ''); ?>">
                        <button type="submit"
                            class="bg-zinc-600 text-white px-6 h-12 ml-2 rounded-lg hover:bg-zinc-700 focus:outline-none focus:bg-zinc-7s00">Iskanje
                        </button>
                    </div>
                </form>
                <!-- Display list of news with edit and delete buttons -->
                <ul class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                    <?php if($news->isEmpty()): ?>
                        <h2 class="p-4 text-gray-900">Nismo našli nobene novice.</h2>
                    <?php else: ?>
                        <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="bg-white rounded-lg shadow-md p-6 overflow-hidden">
                                <h3 class="text-xl font-bold mb-2"><?php echo e($item->title); ?></h3>
                                <p class="text-gray-700 line-clamp-3"><?php echo e($item->content); ?></p>
                                <p class="text-gray-500 mt-2"> <?php echo e($item->created_at->format('d.m.Y')); ?></p>
                                <div class="flex justify-end mt-4">
                                    <a href="<?php echo e(route('news_edit_view', $item->id)); ?>"
                                        class="text-blue-500 hover:underline mr-4">Uredi</a>
                                    <!-- Delete Form with Confirmation Dialog -->
                                    <form id="deleteNewsForm<?php echo e($item->id); ?>"
                                        action="<?php echo e(route('news_destroy', ['news' => $item->id])); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="button"
                                            onclick="showDeleteConfirmation('deleteNewsForm', <?php echo e($item->id); ?>)"
                                            class="text-red-500 hover:underline">Izbriši</button>
                                    </form>
                                </div>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </ul>
                <div class="p-4"><?php echo e($news->links()); ?></div>
            </div>

            <!-- Events Section -->
            <div id="dogodki">
                <?php if (isset($component)) { $__componentOriginala29c4b6de1220dbc50317dc759b47929 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala29c4b6de1220dbc50317dc759b47929 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.title','data' => ['title' => 'Dogodki']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Dogodki']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala29c4b6de1220dbc50317dc759b47929)): ?>
<?php $attributes = $__attributesOriginala29c4b6de1220dbc50317dc759b47929; ?>
<?php unset($__attributesOriginala29c4b6de1220dbc50317dc759b47929); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala29c4b6de1220dbc50317dc759b47929)): ?>
<?php $component = $__componentOriginala29c4b6de1220dbc50317dc759b47929; ?>
<?php unset($__componentOriginala29c4b6de1220dbc50317dc759b47929); ?>
<?php endif; ?>
            </div>
            <div class="container mx-auto mt-3 px-4">
                <!-- Add new events form -->
                <div class="bg-zinc-900 text-white py-2 px-4 rounded-t-lg">
                    <h2 class="text-xl font-bold">Dodaj dogodek</h2>
                </div>
                <form action="<?php echo e(route('events_store')); ?>" method="POST" class="mb-5 bg-gray-100 rounded-lg p-6">
                    <?php echo csrf_field(); ?>
                    <div class="mb-4">
                        <label for="e_title" class="block text-gray-700 font-semibold">Naslov:</label>
                        <input type="text" name="e_title" id="e_title" placeholder="Vnesite naslov dogodka"
                            class="form-input rounded-lg w-full focus:outline-none  border-gray-300 py-3 px-4"
                            value="<?php echo e(old('e_title')); ?>" required>
                        <?php $__errorArgs = ['e_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-3">
                        <label for="e_description" class="block text-gray-700 font-semibold">Vsebina:</label>
                        <textarea name="e_description" id="e_description" placeholder="Vnesite opis dogodka"
                            class="form-textarea rounded-lg w-full h-48 focus:outline-none  border-gray-300 py-3 px-4" required><?php echo e(old('description')); ?></textarea>
                        <?php $__errorArgs = ['e_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-4">
                        <label for="location" class="block text-gray-700 font-semibold">Lokacija:</label>
                        <input type="text" name="location" id="location" placeholder="Vnesite lokacijo dogodka"
                            class="form-input rounded-lg w-full focus:outline-none  border-gray-300 py-3 px-4"
                            value="<?php echo e(old('location')); ?>" required>
                        <?php $__errorArgs = ['location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-4">
                        <label for="start_date" class="block text-gray-700 font-semibold">Datum in čas
                            začetka:</label>
                        <input type="datetime-local" name="fromDate" id="fromDate"
                            class="form-input rounded-lg w-full focus:outline-none  border-gray-300 py-3 px-4"
                            value="<?php echo e(old('start_date')); ?>" required>
                        <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-4">
                        <label for="end_date" class="block text-gray-700 font-semibold">Datum in čas zaključka
                            (neobvezno):</label>
                        <input type="datetime-local" name="toDate" id="toDate"
                            class="form-input rounded-lg w-full focus:outline-none  border-gray-300 py-3 px-4"
                            value="<?php echo e(old('end_date')); ?>">
                        <?php $__errorArgs = ['end_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <button type="submit"
                        class="bg-zinc-500 text-white px-8 py-3 rounded-lg hover:bg-zinc-600 focus:outline-none transition duration-300">
                        Dodaj
                    </button>
                </form>


                <form action="" method="GET" class="flex flex-col items-start">
                    <div class="flex mb-4" id="events">
                        <input type="text" name="search_events" id="search_events" placeholder="Iskanje"
                            class="form-input rounded-lg py-3 px-4 w-full h-12 sm:w-64 mb-2 sm:mb-0 focus:outline-none "
                            value="<?php echo e(isset($search_events) ? $search_events : ''); ?>">
                        <button type="submit"
                            class="bg-zinc-600 text-white px-6 h-12 ml-2 rounded-lg hover:bg-zinc-700 focus:outline-none focus:bg-zinc-7s00">Iskanje
                        </button>
                    </div>
                </form>
                <!-- Display list of events with edit and delete buttons -->
                <ul class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                    <?php if($events->isEmpty()): ?>
                        <h2 class="p-4 text-gray-900">Nismo našli nobenega dogodka.</h2>
                    <?php else: ?>
                        <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="bg-white rounded-lg shadow-md p-6 mb-4 overflow-hidden">
                                <h3 class="text-xl font-bold mb-2"><?php echo e($item->e_title); ?></h3>
                                <p class="text-gray-700 line-clamp-3"><?php echo e($item->e_description); ?></p>
                                <p class="text-gray-500 mt-4">
                                    <span class="text-sm font-semibold">Od:</span>
                                    <span
                                        class="text-sm"><?php echo e(\Carbon\Carbon::parse($item->fromDate)->format('d.m.Y H:i')); ?></span>
                                    <span class="text-sm font-semibold ml-4">Do:</span>
                                    <span
                                        class="text-sm"><?php echo e(\Carbon\Carbon::parse($item->toDate)->format('d.m.Y H:i')); ?></span>
                                    <?php if(isset($item->location)): ?>
                                        <br>
                                        <span class="text-sm font-semibold">Lokacija:</span>
                                        <span class="text-sm"><?php echo e($item->location); ?></span>
                                    <?php endif; ?>
                                </p>
                                <div class="flex justify-end mt-4">
                                    <a href="<?php echo e(route('event_edit', $item->id)); ?>"
                                        class="text-blue-500 hover:underline mr-4">Uredi</a>
                                    <!-- Delete Form with Confirmation Dialog -->
                                    <form id="deleteEventsForm<?php echo e($item->id); ?>"
                                        action="<?php echo e(route('events_destroy', ['event' => $item->id])); ?>"
                                        method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="button"
                                            onclick="showDeleteConfirmation('deleteEventsForm', <?php echo e($item->id); ?>)"
                                            class="text-red-500 hover:underline">Izbriši</button>
                                    </form>
                                </div>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </ul>
                <div class="p-4"><?php echo e($events->links()); ?></div>
            </div>
        </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>

<script>
    function togglePointsInput() {
        var pointsInput = document.getElementById('points');
        var isGroupStageCheckbox = document.getElementById('is_standin');

        pointsInput.disabled = isGroupStageCheckbox.checked;
        if (isGroupStageCheckbox.checked) {
            pointsInput.value = '0';
        }
    }
</script>
<?php /**PATH C:\Users\Nejc Robič\Documents\Projects\Home\TenisTolmin\resources\views\admin\index.blade.php ENDPATH**/ ?>