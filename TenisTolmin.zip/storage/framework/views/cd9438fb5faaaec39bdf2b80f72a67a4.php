<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => ['message' => $message ?? null,'flash' => $flash ?? null,'model' => $model ?? null]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['message' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($message ?? null),'flash' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($flash ?? null),'model' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($model ?? null)]); ?>
    <!-- Include Delete Confirmation Component -->
    <?php if (isset($component)) { $__componentOriginal9502acf056f720678e71cee27afcafd8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9502acf056f720678e71cee27afcafd8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.delete-confirmation','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('delete-confirmation'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9502acf056f720678e71cee27afcafd8)): ?>
<?php $attributes = $__attributesOriginal9502acf056f720678e71cee27afcafd8; ?>
<?php unset($__attributesOriginal9502acf056f720678e71cee27afcafd8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9502acf056f720678e71cee27afcafd8)): ?>
<?php $component = $__componentOriginal9502acf056f720678e71cee27afcafd8; ?>
<?php unset($__componentOriginal9502acf056f720678e71cee27afcafd8); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalf7d3acdbbf96ccd06bb5f5c4e34c0ca7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf7d3acdbbf96ccd06bb5f5c4e34c0ca7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-title-simple','data' => ['title' => 'Liga / Turnir • ' . $league->name]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-title-simple'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Liga / Turnir • ' . $league->name)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf7d3acdbbf96ccd06bb5f5c4e34c0ca7)): ?>
<?php $attributes = $__attributesOriginalf7d3acdbbf96ccd06bb5f5c4e34c0ca7; ?>
<?php unset($__attributesOriginalf7d3acdbbf96ccd06bb5f5c4e34c0ca7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf7d3acdbbf96ccd06bb5f5c4e34c0ca7)): ?>
<?php $component = $__componentOriginalf7d3acdbbf96ccd06bb5f5c4e34c0ca7; ?>
<?php unset($__componentOriginalf7d3acdbbf96ccd06bb5f5c4e34c0ca7); ?>
<?php endif; ?>
    <div class="container mx-auto mt-4">
        <!-- Add new legue form -->
        <div class="bg-zinc-900 text-white py-2 px-4 rounded-t-lg">
            <h2 class="text-xl font-bold">Uredi</h2>
        </div>
        <form action="<?php echo e(route('leagues.edit', ['league' => $league->id])); ?>" method="POST"
            class="mb-5 bg-gray-100 rounded-lg p-6">
            <?php echo method_field('PUT'); ?>
            <?php echo csrf_field(); ?>
            <div class="mb-4">
                <label for="name" class="block text-gray-700 font-semibold">Ime lige ali turnirja:</label>
                <input type="text" name="name" id="name" placeholder="Enter league name"
                    class="form-input rounded-lg w-full focus:outline-none  border-gray-300 py-3 px-4"
                    value="<?php echo e($league->name); ?>" required>
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="mb-4">
                <label for="description" class="block text-gray-700 font-semibold">Opis:</label>
                <textarea name="description" id="description" placeholder="Enter league description"
                    class="form-textarea rounded-lg w-full h-48 focus:outline-none  border-gray-300 py-3 px-4" required><?php echo e($league->description); ?></textarea>
                <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="mb-4">
                <label for="start_date" class="block text-gray-700 font-semibold">Start Date:</label>
                <input type="date" name="start_date" id="start_date"
                    class="form-input rounded-lg w-full focus:outline-none  border-gray-300 py-3 px-4"
                    value="<?php echo e($league->start_date); ?>" required>
                <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="mb-4">
                <label for="end_date" class="block text-gray-700 font-semibold">End Date (neobvezno):</label>
                <input type="date" name="end_date" id="end_date"
                    class="form-input rounded-lg w-full focus:outline-none border-gray-300 py-3 px-4"
                    value="<?php echo e($league->end_date); ?>">
                <?php $__errorArgs = ['end_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <button type="submit"
                class="bg-zinc-500 text-white px-8 py-3 rounded-lg hover:bg-zinc-600 focus:outline-none transition duration-300">Shrani
            </button>
        </form>
    </div>
    <?php if (isset($component)) { $__componentOriginala29c4b6de1220dbc50317dc759b47929 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala29c4b6de1220dbc50317dc759b47929 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.title','data' => ['title' => 'Skupine']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Skupine']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala29c4b6de1220dbc50317dc759b47929)): ?>
<?php $attributes = $__attributesOriginala29c4b6de1220dbc50317dc759b47929; ?>
<?php unset($__attributesOriginala29c4b6de1220dbc50317dc759b47929); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala29c4b6de1220dbc50317dc759b47929)): ?>
<?php $component = $__componentOriginala29c4b6de1220dbc50317dc759b47929; ?>
<?php unset($__componentOriginala29c4b6de1220dbc50317dc759b47929); ?>
<?php endif; ?>

    <div class="bg-gray-200 min-h-screen pt-4">
        <div class="container mx-auto">
            <div class="bg-zinc-900 text-white py-2 px-4 rounded-t-lg">
                <h2 class="text-xl font-bold">Dodaj skupino</h2>
            </div>

            <form action="<?php echo e(route('leagues.bracket_store')); ?>" method="POST" class="mb-5 bg-gray-100 rounded-lg p-6">
                <?php echo csrf_field(); ?>
                <div class="mb-4">
                    <input type="hidden" name="league_id" value="<?php echo e($league->id); ?>">
                    <label for="name" class="block text-gray-700 font-semibold">Ime skupine:</label>
                    <input type="text" name="name" id="name" placeholder="Vnesite ime skupine"
                        class="form-input rounded-lg w-full focus:outline-none focus:border-blue-500 border-gray-300 py-3 px-4"
                        value="<?php echo e(old('name')); ?>" required>
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-6">
                    <label for="is_group_stage">Skupinski del</label>
                    <input type="checkbox" name="is_group_stage" id="is_group_stage" class="ml-2" value="1">
                    <?php $__errorArgs = ['is_group_stage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-4" id="pointsDescriptionContainer">
                    <label for="points_description" class="block text-gray-700 font-semibold">Opis števila
                        točk:</label>
                    <input type="text" name="points_description" id="points_description"
                        placeholder="Vnesite opis števila točk pridobljenih glede na doseženo mesto"
                        class="form-input rounded-lg w-full focus:outline-none focus:border-blue-500 border-gray-300 py-3 px-4"
                        value="<?php echo e(old('points_description')); ?>">
                    <?php $__errorArgs = ['points_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-4" id="pointsDescriptionContainer">
                    <label for="tag" class="block text-gray-700 font-semibold">Oznaka skupine:</label>
                    <input type="text" name="tag" id="tag" placeholder="Vpišite oznako skupine (Primer: A)"
                        class="form-input rounded-lg w-full focus:outline-none focus:border-blue-500 border-gray-300 py-3 px-4"
                        value="<?php echo e(old('tag')); ?>" disabled>
                    <?php $__errorArgs = ['tag'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mt-4 mb-4" id="teamsContainer">
                    <label for="teams"
                        class="block bg-gray-600 text-white font-semibold py-2 mb-2 px-4 rounded">Ekipe:</label>
                    <div id="teamsInputs">
                        <div class="mb-2 teamInput">
                            <label for="teams"
                                class="block bg-gray-400 text-white font-semibold text-sm py-1 mb-2 px-4 rounded">Ekipa
                                1</label>
                            <div class="border-b-2 border-gray-300 pb-4">
                                <div>
                                    <label for="teamName" class="block text-gray-700 font-semibold">Ime ekipe:</label>
                                    <input type="text" name="teams[0][name]" id="teamName"
                                        placeholder="Ime ekipe (neobvezno)"
                                        class="form-input rounded-lg w-full focus:outline-none focus:border-blue-500 border-gray-300 py-3 px-4 mt-3">
                                </div>
                                <div>
                                    <label for="firstPlayer" class="block text-gray-700 font-semibold mt-3">Prvi
                                        igralec:</label>
                                    <select name="teams[0][player_ids][]" id="firstPlayer"
                                        class="form-select rounded-lg w-full focus:outline-none focus:border-blue-500 border-gray-300 py-3 px-4 mt-1"
                                        required>
                                        <option value="">Izberi prvega igralca</option>
                                        <!-- Use foreach to generate dropdown options for players -->
                                        <?php $__currentLoopData = $playersSelect; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($player->id); ?>"><?php echo e($player->p_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['teams.0.player_ids.0'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        
                                        <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div>
                                    <label for="secondPlayer" class="block text-gray-700 font-semibold mt-3">Drugi
                                        igralec:</label>
                                    <select name="teams[0][player_ids][]" id="secondPlayer"
                                        class="form-select rounded-lg w-full focus:outline-none focus:border-blue-500 border-gray-300 py-3 px-4 mt-1">
                                        <option value="">Izberi drugega igralca (neobvezno)</option>
                                        <!-- Use foreach to generate dropdown options for players -->
                                        <?php $__currentLoopData = $playersSelect; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($player->id); ?>"><?php echo e($player->p_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['teams.0.player_ids.1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        
                                        <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    <button type="button" id="addTeamBtn"
                        class="bg-zinc-900 text-white px-4 py-2 rounded-lg hover:bg-zinc-800 focus:outline-none mt-4">Dodaj
                        ekipo</button>
                </div>

                <button type="submit"
                    class="bg-zinc-500 text-white px-8 py-3 rounded-lg hover:bg-zinc-600 focus:outline-none transition duration-300 mt-2">Dodaj
                    skupino
                </button>
            </form>

            <!-- Display list of brackets with edit and delete buttons -->
            <ul class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                <?php if($brackets->isEmpty()): ?>
                    <h2 class="p-4 text-gray-900">Nismo našli nobene skupine.</h2>
                <?php else: ?>
                    <?php $__currentLoopData = $brackets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="bg-white rounded-lg shadow-md p-6 mb-6">
                            <div class="flex items-center justify-between mb-4">
                                <div>
                                    <h3 class="text-xl font-bold mb-2"><?php echo e($item->name); ?></h3>
                                    <p class="text-gray-700"><?php echo e($item->b_description); ?></p>
                                </div>
                                <p class="text-sm font-semibold text-gray-500">
                                    <?php echo e($item->teams->where('is_fake', false)->count()); ?>

                                    igralcev/ekip</p>
                            </div>
                            <div class="text-sm underline text-gray-500">
                                <?php echo e($item->is_group_stage ? 'Skupinski del' : 'Izločitveni del'); ?></div>
                            <div class="flex items-center justify-between">
                                <p>
                                    <span class="text-sm font-semibold text-gray-500">Ustvarjeno:</span>
                                    <span
                                        class="text-sm text-gray-500"><?php echo e(\Carbon\Carbon::parse($item->created_at)->format('d.m.Y')); ?></span>
                                </p>
                                <div class="flex items-center">
                                    <a href="<?php echo e(route('matchup_setup', $item->id)); ?>"
                                        class="text-blue-500 hover:underline mr-4">Uredi</a>
                                    <form id="deleteForm<?php echo e($item->id); ?>"
                                        action="<?php echo e(route('league.bracket_destroy', ['bracket' => $item->id])); ?>"
                                        method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="button"
                                            onclick="showDeleteConfirmation('deleteForm', <?php echo e($item->id); ?>)"
                                            class="text-red-500 hover:underline">Izbriši</button>
                                    </form>
                                </div>
                            </div>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </ul>
            <div class="p-4"><?php echo e($brackets->links()); ?></div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>

<style>
    .removeTeamBtn {
        background-color: transparent;
        border: none;
        margin-top: 10px;
        color: #EF4444;
        cursor: pointer;
        font-size: 15px;
        outline: none;
        transition: color 0.3s ease;
    }

    .removeTeamBtn:hover {
        color: #DC2626;
    }

    input:disabled {
        background-color: #e2e5ea;
        /* Custom color */
    }
</style>

<script>
    // Add team input field
    function addTeamInput() {
        const teamsContainer = document.getElementById('teamsInputs');
        const teamIndex = teamsContainer.children.length; // Get the number of teams
        const newInput = document.createElement('div');
        newInput.classList.add('mb-2', 'teamInput');
        newInput.innerHTML = `<div class="border-b-2 border-gray-300 pb-4">
            <label for="teams" class="block bg-gray-400 text-white font-semibold text-sm py-1 mb-2 px-4 rounded">Ekipa ${teamIndex + 1}</label>
                            <label for="teamName" class="block text-gray-700 font-semibold">Ime ekipe:</label>
                            <input type="text" name="teams[${teamIndex}][name]" placeholder="Ime ekipe (neobvezno)"
                                class="form-input rounded-lg w-full focus:outline-none focus:border-blue-500 border-gray-300 py-3 px-4 mt-3">
                                <label for="firstPlayer" class="block text-gray-700 font-semibold mt-3">Prvi
                                        igralec:</label>
                            <select name="teams[${teamIndex}][player_ids][]" class="form-select rounded-lg w-full focus:outline-none focus:border-blue-500 border-gray-300 py-3 px-4 mt-3" required>
                                <option value="">Izberi prvega igralca</option>
                                <!-- Use foreach to generate dropdown options for players -->
                                <?php $__currentLoopData = $playersSelect; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($player->id); ?>"><?php echo e($player->p_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['teams.${teamIndex}.player_ids.0'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <label for="secondPlayer" class="block text-gray-700 font-semibold mt-3">Drugi
                                        igralec:</label>
                            <select name="teams[${teamIndex}][player_ids][]" class="form-select rounded-lg w-full focus:outline-none focus:border-blue-500 border-gray-300 py-3 px-4 mt-1">
                                <option value="">Izberi drugega igralca (neobvezno)</option>
                                <!-- Use foreach to generate dropdown options for players -->
                                <?php $__currentLoopData = $playersSelect; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($player->id); ?>"><?php echo e($player->p_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['teams.${teamIndex}.player_ids.1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <button type="button" class="removeTeamBtn ml-2">Odstrani</button>
                        </div>`;
        teamsContainer.appendChild(newInput);
        // Add event listener to remove button
        newInput.querySelector('.removeTeamBtn').addEventListener('click', function() {
            teamsContainer.removeChild(newInput);
        });
    }

    document.getElementById('addTeamBtn').addEventListener('click', addTeamInput);

    // Ensure that the value of is_group_stage is set to "0" if the checkbox is not checked when the form is submitted
    const form = document.querySelector('form');
    form.addEventListener('submit', function() {
        const isGroupStageCheckbox = document.getElementById('is_group_stage');
        if (!isGroupStageCheckbox.checked) {
            // Create a hidden input field for is_group_stage with value "0"
            const hiddenInput = document.createElement('input');
            hiddenInput.type = 'hidden';
            hiddenInput.name = 'is_group_stage';
            hiddenInput.value = '0';
            form.appendChild(hiddenInput);
        }
    });

    // Function to enable/disable the points description input based on checkbox status
    document.getElementById('is_group_stage').addEventListener('change', function() {
        var pointsDescriptionInput = document.getElementById('points_description');
        var tagInput = document.getElementById('tag');
        pointsDescriptionInput.disabled = this.checked;
        tagInput.disabled = !this.checked;
    });

    document.addEventListener('DOMContentLoaded', function() {
        const skupineNameInput = document.getElementById('name'); // Skupine name input

        skupineNameInput.addEventListener('click', function(event) {
            // Stop the propagation of the click event to prevent focusing on the league name input
            event.stopPropagation();
        });
    });
</script>
<?php /**PATH C:\Users\Nejc Robič\Documents\Projects\Home\TenisTolmin\resources\views\admin\bracket_store.blade.php ENDPATH**/ ?>