
<div class="mt-8">
    <span class="text-xl font-semibold mb-4">Komentarji<p class="inline text-xs font-semibold text-green-600"> (prihajajo kmalu)</p></span>
    
    <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="bg-gray-100 rounded-lg shadow-md p-4 mb-4">
            <p class="text-gray-700 text-sm"><?php echo e($comment['content']); ?></p>
            <div class="flex justify-between items-center mt-2">
                <p class="text-gray-500 text-xs">Commented by <span
                        class="font-semibold"><?php echo e($comment['username'] ?? 'John Doe'); ?></span> | <span
                        
                        class="font-semibold"><?php echo e($comment['created_at']->format('d.m.Y')); ?></span></p>
                
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    <?php if(auth()->guard()->check()): ?>
        <form method="POST" class="mt-8 bg-gray-200 rounded-lg shadow-md p-4">
            <?php echo csrf_field(); ?>
            <div class="mb-4">
                <label for="content" class="block text-gray-700">Comment:</label>
                <textarea name="content" id="content" rows="4" class="form-textarea mt-1 block w-full" required></textarea>
            </div>
            <button type="submit" class="bg-gray-900 text-white py-2 px-4 rounded hover:bg-gray-800">Submit
                Comment</button>
        </form>
    <?php else: ?>
        <p class="text-gray-600 mb-10">Prijavite se, in komentirajte.</p>
    <?php endif; ?>
</div>
<?php /**PATH C:\Users\Nejc Robič\Documents\Projects\Home\TenisTolmin\resources\views\partials\_comments.blade.php ENDPATH**/ ?>